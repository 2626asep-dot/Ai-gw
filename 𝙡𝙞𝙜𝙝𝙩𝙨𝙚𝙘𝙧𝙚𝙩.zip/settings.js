/*
=========================================================================
█░ █ █▀▀ █░█ ▀█▀  
█▄ █ █▄█ █▀█ ░█░  
█▀ █▀▀ █▀ █▀█ █▀▀ ▀█▀  
▄█ ██▄ █▄ █▀▄ ██▄ ░█░
CONTACT TELEGRAM : t.me/lightsecrett
   
=========================================================================
*/

const settings = {
  owner: '8321371110', // ID Telegram Owner
  token: '8500943505:AAH8zEBAvBxdKwwyIcXMU9wQcLy3RL6EuqI', // Token Bot Telegram
  domain: 'https://-', // Domain Panel
  plta: 'ptla', // API Key Panel Admin
  pltc: 'ptlc', // API Key Panel Client
  loc: '1', // Lokasi VPS
  eggs: '15', // Egg ID
};

// =====================================================================
// ⚙️ Export Konfigurasi
// =====================================================================

module.exports = settings;