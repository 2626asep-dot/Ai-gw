const TelegramBot = require('node-telegram-bot-api');
const axios = require('axios');
const chalk = require('chalk');
const { ImageUploadService } = require('node-upload-images');
const fs = require('fs');
const crypto = require('crypto');
const { Client } = require('ssh2'); // ← gunakan SSH2
const yts = require('yt-search');
const ytdl = require('ytdl-core');
const os = require('os');
const { tiktokDl } = require('./scraper');
const fetch = require('node-fetch');
const settings = require('./settings');
const token = settings.token;
const domain = settings.domain;
const plta = settings.plta;
const pltc = settings.pltc;
const premiumUsersFile = 'premiumUsers.json';
const owner = settings.owner;
const ram = (os.totalmem() / Math.pow(1024, 3)).toFixed(2) + ' GB';
    const freeRam = (os.freemem() / Math.pow(1024, 3)).toFixed(2) + ' GB';
try {
    premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
} catch (error) {
    console.error('Error reading premiumUsers file:', error);
}

const bot = new TelegramBot(token, { polling: true });

// ─── URL Gambar ───────────────────────────────
const startImageUrl     = 'https://img1.pixhost.to/images/9584/653719301_ochobot.jpg';
const panelImageUrl     = 'https://img1.pixhost.to/images/9584/653719301_ochobot.jpg';
const ownerImageUrl     = 'https://img1.pixhost.to/images/9584/653719301_ochobot.jpg';
const fiturImageUrl     = 'https://img1.pixhost.to/images/9584/653719301_ochobot.jpg';
const cekIdImageUrl     = 'https://img1.pixhost.to/images/9584/653719301_ochobot.jpg';
const installImageUrl   = 'https://img1.pixhost.to/images/9584/653719301_ochobot.jpg';

const groupUrl  = 'https://t.me/lightsecrettpublik';
const chanelUrl = 'https://t.me/lightsecrettChanel';
const panelUrl  = 'https://img1.pixhost.to/images/9584/653719301_ochobot.jpg';


// ─── Fungsi Menu Start ───────────────────────────────
const sendStartMenu = (chatId, messageId, username) => {
  const caption = `✨ Hai ${username}!
╭─────〔 𝙋𝙍𝙊𝙏𝙀𝘾𝙏 𝙎𝙏𝘼𝙍𝙏 〕───────╮
│♞ ɴᴀᴍᴇ ʙᴏᴛ : ᴘʀᴏᴛᴇᴄᴛ ᴘᴛᴇʀᴏᴅᴀᴄᴛʏʟ
│♚ ᴠᴇʀsɪᴏɴ : 𝙁𝙍𝙀𝙀
│♝ ᴅᴇᴠᴇʟᴏᴘᴇʀ : @lightsecrett
│♜ ᴏᴡɴᴇʀ : @lightsecrett
│♛ ɪɴғᴏʀᴍᴀᴛɪᴏɴ : t.me/lightsecrett
╰──────────────────────────╯

Selamat datang di 𝙇𝙞𝙜𝙝𝙩𝙎𝙚𝙘𝙧𝙚𝙩 𝙆𝙚𝙗𝙪𝙩𝙪𝙝𝙖𝙣 𝙋𝙖𝙣𝙚𝙡 𝘽𝙤𝙩 ⚙️  
Dibuat dengan hati oleh @lightsecrett.

Silakan pilih menu di bawah ini untuk mulai 🚀`;

  bot.editMessageMedia(
    { type: 'photo', media: startImageUrl, caption },
    {
      chat_id: chatId,
      message_id: messageId,
      reply_markup: {
        inline_keyboard: [
          [
            { text: '𝙄𝙣𝙨𝙩𝙖𝙡𝙡 𝙈𝙚𝙣𝙪', callback_data: 'install_menu' }
          ],
          [
            { text: '𝙁𝙞𝙩𝙪𝙧 𝙈𝙚𝙣𝙪', callback_data: 'fitur_menu' },
            { text: '𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧', url: 'https://t.me/lightsecrett' }
          ],
          [
            { text: '𝙋𝙖𝙣𝙚𝙡 𝙈𝙚𝙣𝙪', callback_data: 'panel_menu' },
            { text: '𝙊𝙬𝙣𝙚𝙧 𝙈𝙚𝙣𝙪', callback_data: 'owner_menu' }
          ]
        ]
      }
    }
  );
};


// ─── Fungsi Menu Panel ───────────────────────────────
const sendPanelMenu = (chatId, messageId, username) => {
  const caption = `👋 Hai @${username}, berikut daftar ᴾᵃⁿᵉˡ ᴹᵉⁿᵘ yang tersedia:

/1gb user,idtele
/2gb user,idtele
/3gb user,idtele
/4gb user,idtele
/5gb user,idtele
/6gb user,idtele
/7gb user,idtele
/8gb user,idtele
/9gb user,idtele
/10gb user,idtele
/unli user,idtele

👨‍💻 Developer: @lightsecrett`;

  bot.editMessageMedia(
    { type: 'photo', media: panelImageUrl, caption },
    {
      chat_id: chatId,
      message_id: messageId,
      reply_markup: {
        inline_keyboard: [[{ text: '𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'start_menu' }]]
      }
    }
  );
};


// ─── Fungsi Menu Owner ───────────────────────────────
const sendOwnerMenu = (chatId, messageId, username) => {
  const caption = `🧠 Hai @${username}, berikut ᴼʷⁿᵉʳ ᴹᵉⁿᵘ:

/createadmin username,idtele
/listusr
/delusr
/listsrv
/delsrv
/addprem
/delprem
/listprem
/domain
/plta
/pltc

👨‍💻 Developer: @lightsecrett`;

  bot.editMessageMedia(
    { type: 'photo', media: ownerImageUrl, caption },
    {
      chat_id: chatId,
      message_id: messageId,
      reply_markup: {
        inline_keyboard: [[{ text: '𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'start_menu' }]]
      }
    }
  );
};


// ─── Fungsi Menu Fitur ───────────────────────────────
const sendFiturMenu = (chatId, messageId, username) => {
  const caption = `⚙️ Hai @${username}, berikut 𝙁𝙞𝙩𝙪𝙧 𝙈𝙚𝙣𝙪 yang bisa kamu coba:

/gptai perintah/ataupertanyaan
/cekid
/cekpacar
/cekkendaraan
/cekkhodam
/tiktok url
/tourl
/play namalagu
/brat teks

👨‍💻 Developer: @lightsecrett`;

  bot.editMessageMedia(
    { type: 'photo', media: fiturImageUrl, caption },
    {
      chat_id: chatId,
      message_id: messageId,
      reply_markup: {
        inline_keyboard: [[{ text: '𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'start_menu' }]]
      }
    }
  );
};

// ─── Fungsi Menu Install ───────────────────────────────
const sendInstallMenu = (chatId, messageId, username) => {
  const caption = `👽 𝙁𝙄𝙏𝙐𝙍 𝙄𝙉𝙎𝙏𝘼𝙇𝙇 𝙈𝙀𝙉𝙐 👑
𝙂𝙪𝙣𝙖𝙠𝙖𝙣 𝙥𝙚𝙧𝙞𝙣𝙩𝙖𝙝 𝙙𝙞 𝙗𝙖𝙬𝙖𝙝 𝙞𝙣𝙞 𝙪𝙣𝙩𝙪𝙠 𝙢𝙚𝙢𝙖𝙨𝙖𝙣𝙜 𝙞𝙣𝙨𝙩𝙖𝙡𝙡 𝙨𝙚𝙨𝙪𝙖𝙞 𝙠𝙚𝙗𝙪𝙩𝙪𝙝𝙖𝙣𝙢𝙪 🚀

/𝗶𝗻𝘀𝘁𝗮𝗹𝗹𝗽𝗮𝗻𝗲𝗹 ipvps|pwvps|panel.domain|node.domain|ram
/𝘂𝗻𝗶𝗻𝘀𝘁𝗮𝗹𝗹𝗽𝗮𝗻𝗲𝗹 ipvps|pwvps
/𝗵𝗮𝗰𝗸𝗯𝗮𝗰𝗸𝗽𝗮𝗻𝗲𝗹 ipvps|pwvps
/𝗶𝗻𝘀𝘁𝗮𝗹𝗹𝘄𝗶𝗻𝗴𝘀 ipvps|pwvps|nodedomain.com
/𝘂𝗻𝗶𝗻𝘀𝘁𝗮𝗹𝗹𝘄𝗶𝗻𝗴𝘀 ipvps|pwvps
/𝘀𝘁𝗮𝗿𝘁𝘄𝗶𝗻𝗴𝘀 ipvps|pwvps
/𝘀𝘂𝗯𝗱𝗼𝗺𝗮𝗶𝗻 nama|ipvps
/𝗱𝗲𝗹𝘀𝘂𝗯𝗱𝗼𝗺𝗮𝗶𝗻 linkdomain

✨ 𝙋𝙖𝙨𝙩𝙞𝙠𝙖𝙣 𝙨𝙚𝙧𝙫𝙚𝙧 𝙖𝙠𝙩𝙞𝙛 𝙨𝙚𝙗𝙚𝙡𝙪𝙢 𝙢𝙚𝙣𝙟𝙖𝙡𝙖𝙣𝙠𝙖𝙣 𝙞𝙣𝙨𝙩𝙖𝙡𝙖𝙨𝙞! ⚙️`;

  bot.editMessageMedia(
    { type: 'photo', media: installImageUrl, caption },
    {
      chat_id: chatId,
      message_id: messageId,
      reply_markup: {
        inline_keyboard: [[{ text: '𝙆𝙚𝙢𝙗𝙖𝙡𝙞', callback_data: 'start_menu' }]]
      }
    }
  );
};

// ─── Command: /start ───────────────────────────────
bot.onText(/^\/start$/, (msg) => {
  const chatId = msg.chat.id;
  const username = msg.from.username || msg.from.first_name;

  const caption = `✨ Hai ${username}!
╭─────〔 𝙋𝙍𝙊𝙏𝙀𝘾𝙏 𝙎𝙏𝘼𝙍𝙏 〕───────╮
│♞ ɴᴀᴍᴇ ʙᴏᴛ : ᴘʀᴏᴛᴇᴄᴛ ᴘᴛᴇʀᴏᴅᴀᴄᴛʏʟ
│♚ ᴠᴇʀsɪᴏɴ : 3.0 𝙑𝙄𝙋
│♝ ᴅᴇᴠᴇʟᴏᴘᴇʀ : @lightsecrett
│♜ ᴏᴡɴᴇʀ : @lightsecrett
│♛ ɪɴғᴏʀᴍᴀᴛɪᴏɴ : t.me/lightsecrett
╰──────────────────────────╯

Selamat datang di 𝙇𝙞𝙜𝙝𝙩𝙎𝙚𝙘𝙧𝙚𝙩 𝙆𝙚𝙗𝙪𝙩𝙪𝙝𝙖𝙣 𝙋𝙖𝙣𝙚𝙡 𝘽𝙤𝙩 ⚙️  
Dibuat dengan hati oleh @lightsecrett.

Silakan pilih menu di bawah ini untuk mulai 🚀`;

  const options = {
    reply_markup: {
      inline_keyboard: [
        [
          { text: '𝙄𝙣𝙨𝙩𝙖𝙡𝙡 𝙈𝙚𝙣𝙪', callback_data: 'install_menu' },
          { text: '𝙁𝙞𝙩𝙪𝙧 𝙈𝙚𝙣𝙪', callback_data: 'fitur_menu' }
        ],
        [
          { text: '𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧', url: 'https://t.me/lightsecrett' }
        ],
        [
          { text: '𝙋𝙖𝙣𝙚𝙡 𝙈𝙚𝙣𝙪', callback_data: 'panel_menu' },
          { text: '𝙊𝙬𝙣𝙚𝙧 𝙈𝙚𝙣𝙪', callback_data: 'owner_menu' }
        ]
      ]
    }
  };

  bot.sendPhoto(chatId, startImageUrl, { caption, ...options });
});


// ─── CALLBACK HANDLER ───────────────────────────────
bot.on('callback_query', async (query) => {
  const chatId = query.message.chat.id;
  const messageId = query.message.message_id;
  const username = query.from.username || query.from.first_name;
  const data = query.data;

  try {
    switch (data) {
      case 'start_menu': 
        sendStartMenu(chatId, messageId, username); 
        break;
      case 'panel_menu': 
        sendPanelMenu(chatId, messageId, username); 
        break;
      case 'owner_menu': 
        sendOwnerMenu(chatId, messageId, username); 
        break;
      case 'fitur_menu': 
        sendFiturMenu(chatId, messageId, username); 
        break;
      case 'install_menu': 
        sendInstallMenu(chatId, messageId, username); 
        break;

      default:
        bot.answerCallbackQuery(query.id, { text: 'Menu tidak dikenal.' });
        break;
    }
  } catch (err) {
    console.error('❌ Error callback:', err);
    bot.answerCallbackQuery(query.id, { text: 'Terjadi kesalahan.' });
  }
});

//gpt ai fitur
bot.onText(/^\/gptai (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1]; // teks setelah perintah /gptai

  try {
    const question = "ChatGPT";
    const prompt = encodeURIComponent(text);
    const url = `https://api.zenzxz.my.id/api/ai/gpt?question=${question}&prompt=${prompt}`;

    const response = await fetch(url);
    const result = await response.json();

    if (!result.success) {
      return bot.sendMessage(chatId, "❌ Gagal mendapatkan respon dari AI.");
    }

    await bot.sendMessage(chatId, result.results);
  } catch (err) {
    console.error(err);
    await bot.sendMessage(chatId, "⚠️ Terjadi kesalahan saat menghubungi API GPT.");
  }
});

bot.onText(/^\/gptai$/, (msg) => {
  bot.sendMessage(msg.chat.id, "📘 Contoh penggunaan:\n/gptai Hai siapa kamu");
});

// ─── Random Blue Archive Command ───────────────────────────
bot.onText(/^\/randombluearchive$/, async (msg) => {
  const chatId = msg.chat.id;

  const waitMessage = await bot.sendMessage(
    chatId,
    "🎲 𝙈𝙚𝙣𝙜𝙖𝙢𝙗𝙞𝙡 𝙜𝙖𝙢𝙗𝙖𝙧 𝘽𝙡𝙪𝙚 𝘼𝙧𝙘𝙝𝙞𝙫𝙚, 𝙩𝙪𝙣𝙜𝙜𝙪 𝙨𝙚𝙗𝙚𝙣𝙩𝙖𝙧..."
  );

  try {
    // Tambahkan query acak agar tidak kena cache
    const randomParam = `?nocache=${Date.now()}_${Math.random()}`;
    const imageUrl = `https://api.zenzxz.my.id/api/random/bluearchive${randomParam}`;

    // Hapus pesan loading
    await bot.deleteMessage(chatId, waitMessage.message_id);

    // Kirim foto + tombol refresh
    await bot.sendPhoto(chatId, imageUrl, {
      caption: "📸 𝙍𝙖𝙣𝙙𝙤𝙢 𝘽𝙡𝙪𝙚 𝘼𝙧𝙘𝙝𝙞𝙫𝙚 𝙄𝙢𝙖𝙜𝙚",
      reply_markup: {
        inline_keyboard: [
          [
            { text: "↻𝗥𝗲𝗳𝗿𝗲𝘀𝗵", callback_data: "refresh_bluearchive" },
          ],
        ],
      },
    });
  } catch (err) {
    console.error("❌ Error:", err.message);
    await bot.sendMessage(
      chatId,
      "❌ 𝙏𝙚𝙧𝙟𝙖𝙙𝙞 𝙠𝙚𝙨𝙖𝙡𝙖𝙝𝙖𝙣 𝙨𝙖𝙖𝙩 𝙢𝙚𝙣𝙜𝙖𝙢𝙗𝙞𝙡 𝙜𝙖𝙢𝙗𝙖𝙧. 𝘾𝙤𝙗𝙖 𝙡𝙖𝙜𝙞 𝙣𝙖𝙣𝙩𝙞!"
    );
  }
});

// ─── Callback Refresh Button ───────────────────────────────
bot.on("callback_query", async (query) => {
  const chatId = query.message.chat.id;
  const messageId = query.message.message_id;

  if (query.data === "refresh_bluearchive") {
    try {
      const randomParam = `?nocache=${Date.now()}_${Math.random()}`;
      const imageUrl = `https://api.zenzxz.my.id/api/random/bluearchive${randomParam}`;

      await bot.editMessageMedia(
        {
          type: "photo",
          media: imageUrl,
          caption: "📸 𝙍𝙖𝙣𝙙𝙤𝙢 𝘽𝙡𝙪𝙚 𝘼𝙧𝙘𝙝𝙞𝙫𝙚 𝙄𝙢𝙖𝙜𝙚",
        },
        {
          chat_id: chatId,
          message_id: messageId,
          reply_markup: {
            inline_keyboard: [
              [{ text: "↻𝗥𝗲𝗳𝗿𝗲𝘀𝗵", callback_data: "refresh_bluearchive" }],
            ],
          },
        }
      );

      // Jawab callback agar tombol tidak loading lama
      await bot.answerCallbackQuery(query.id, { text: "🔄 Gambar diperbarui!" });
    } catch (err) {
      console.error("❌ Error refresh:", err.message);
      await bot.answerCallbackQuery(query.id, {
        text: "⚠️ Gagal memuat gambar baru.",
        show_alert: true,
      });
    }
  }
});

// ─── Random Loli Archive Command ───────────────────────────
bot.onText(/^\/randomloli$/, async (msg) => {
  const chatId = msg.chat.id;

  const waitMessage = await bot.sendMessage(
    chatId,
    "🎲 𝙈𝙚𝙣𝙜𝙖𝙢𝙗𝙞𝙡 𝙜𝙖𝙢𝙗𝙖𝙧 𝙇𝙤𝙡𝙞 𝘼𝙧𝙘𝙝𝙞𝙫𝙚, 𝙩𝙪𝙣𝙜𝙜𝙪 𝙨𝙚𝙗𝙚𝙣𝙩𝙖𝙧..."
  );

  try {
    // Tambahkan query acak agar tidak kena cache
    const randomParam = `?nocache=${Date.now()}_${Math.random()}`;
    const imageUrl = `https://api.zenzxz.my.id/api/random/loli${randomParam}`;

    // Hapus pesan loading
    await bot.deleteMessage(chatId, waitMessage.message_id);

    // Kirim foto + tombol refresh
    await bot.sendPhoto(chatId, imageUrl, {
      caption: "📸 𝙍𝙖𝙣𝙙𝙤𝙢 𝙇𝙤𝙡𝙞 𝘼𝙧𝙘𝙝𝙞𝙫𝙚 𝙄𝙢𝙖𝙜𝙚",
      reply_markup: {
        inline_keyboard: [
          [
            { text: "↻𝗥𝗲𝗳𝗿𝗲𝘀𝗵", callback_data: "refresh_loli" },
          ],
        ],
      },
    });
  } catch (err) {
    console.error("❌ Error:", err.message);
    await bot.sendMessage(
      chatId,
      "❌ 𝙏𝙚𝙧𝙟𝙖𝙙𝙞 𝙠𝙚𝙨𝙖𝙡𝙖𝙝𝙖𝙣 𝙨𝙖𝙖𝙩 𝙢𝙚𝙣𝙜𝙖𝙢𝙗𝙞𝙡 𝙜𝙖𝙢𝙗𝙖𝙧. 𝘾𝙤𝙗𝙖 𝙡𝙖𝙜𝙞 𝙣𝙖𝙣𝙩𝙞!"
    );
  }
});

// ─── Callback Refresh Button ───────────────────────────────
bot.on("callback_query", async (query) => {
  const chatId = query.message.chat.id;
  const messageId = query.message.message_id;

  // Handle refresh untuk random loli
  if (query.data === "refresh_loli") {
    try {
      const randomParam = `?nocache=${Date.now()}_${Math.random()}`;
      const imageUrl = `https://api.zenzxz.my.id/api/random/loli${randomParam}`;

      await bot.editMessageMedia(
        {
          type: "photo",
          media: imageUrl,
          caption: "📸 𝙍𝙖𝙣𝙙𝙤𝙢 𝙇𝙤𝙡𝙞 𝘼𝙧𝙘𝙝𝙞𝙫𝙚 𝙄𝙢𝙖𝙜𝙚",
        },
        {
          chat_id: chatId,
          message_id: messageId,
          reply_markup: {
            inline_keyboard: [
              [{ text: "↻𝗥𝗲𝗳𝗿𝗲𝘀𝗵", callback_data: "refresh_loli" }],
            ],
          },
        }
      );

      // Hilangkan loading di tombol
      await bot.answerCallbackQuery(query.id, { text: "🔄 Gambar diperbarui!" });
    } catch (err) {
      console.error("❌ Error refresh:", err.message);
      await bot.answerCallbackQuery(query.id, {
        text: "⚠️ Gagal memuat gambar baru.",
        show_alert: true,
      });
    }
  }
});

// Handle perintah /cekid
bot.onText(/\/cekid/, (msg) => {
    const chatId = msg.chat.id;
    const username = msg.from.username || msg.from.first_name;
    const idTele = msg.from.id;

    bot.sendPhoto(chatId, cekIdImageUrl, {
        caption: `Hi @${username} 👋\n\nID Telegram Anda: ${idTele}\nUsername Anda: @${username}\n\nItu adalah ID Telegram Anda 🤗\nDeveloper: @lightsecrett`
    });
});

// Handle perintah /cekpacar
bot.onText(/\/cekpacar/, (msg) => {
    const chatId = msg.chat.id;
    const username = msg.from.username || msg.from.first_name;

    // Daftar nama pacar yang dipilih secara acak
    const pacarList = [
        "Siti", "Senti", "Sifa", "Aprel", "Ika", "Cahya", "Mifta", 
        "Asraf", "Suep", "Jamal", "Akmal", "Supri", "Josep", 
        "Agus", "Akbar", "Dian", "Gak ada ☠️"
    ];

    // Pilih nama pacar secara acak
    const pacar = pacarList[Math.floor(Math.random() * pacarList.length)];

    // Kirim pesan ke pengguna
    bot.sendMessage(chatId, `@${username}, pacarmu adalah *${pacar}* ❤️`, { parse_mode: "Markdown" });
});

/// Handle perintah /cekkhodam dengan regex agar lebih fleksibel
bot.onText(/\/cekkhodam\s*/i, (msg) => {
    const chatId = msg.chat.id;
    const username = msg.from.username || msg.from.first_name;

    // Daftar Khodam yang dipilih secara acak
    const khodamList = [
        "Tumis Kangkung", "Topi Melorot", "Nyu Blorong", "Rayap Gendut", 
        "LC Karaoke", "Cicak Kawin", "Sundel Bolong", "Tuyul Kesandung", 
        "Genderuwo TikTok", "Pocong Bersepeda", "Tuyul Main PS5", "Kompor Meledak"
    ];

    // Pilih khodam secara acak
    const khodam = khodamList[Math.floor(Math.random() * khodamList.length)];

    // Kirim pesan ke pengguna
    bot.sendMessage(chatId, `@${username}, Khodam mu adalah *${khodam}* 🔥`, { parse_mode: "Markdown" });
});

// Daftar URL gambar kendaraan (ganti dengan URL kendaraan sesuai kebutuhan)
const kendaraanImages = [
    "https://img12.pixhost.to/images/1064/578151475_uploaded_image.jpg",
    "https://img12.pixhost.to/images/1064/578151478_uploaded_image.jpg",
    "https://img12.pixhost.to/images/1064/578151497_uploaded_image.jpg",
    "https://img12.pixhost.to/images/1064/578151503_uploaded_image.jpg",
    "https://img12.pixhost.to/images/1064/578151606_uploaded_image.jpg"
];

// Handle perintah /cekkendaraan
bot.onText(/\/cekkendaraan\s*/i, (msg) => {
    const chatId = msg.chat.id;
    const username = msg.from.username || msg.from.first_name;

    // Pilih gambar kendaraan secara acak
    const randomImage = kendaraanImages[Math.floor(Math.random() * kendaraanImages.length)];

    // Kirim gambar dengan caption
    bot.sendPhoto(chatId, randomImage, {
        caption: `@${username}, Itulah kendaraanmu sekarang 🚗`,
        parse_mode: "Markdown"
    });
});

bot.onText(/^(\.|\#|\/)tiktok$/, async (msg) => {
    const chatId = msg.chat.id;
    bot.sendMessage(chatId, `Format salah example /tiktok link`);
  });
  

bot.onText(/\/tiktok (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const text = match[1]; // Mengambil teks setelah perintah /tt

    if (!text.startsWith("https://")) {
        return bot.sendMessage(chatId, "Masukkan URL TikTok yang valid!");
    }

    try {
        bot.sendMessage(chatId, "⏳ Proses Kakkk");

        const result = await tiktokDl(text);

        if (!result.status) {
            return bot.sendMessage(chatId, "Terjadi kesalahan saat memproses URL!");
        }

        if (result.durations === 0 && result.duration === "0 Seconds") {
            let mediaArray = [];

            for (let i = 0; i < result.data.length; i++) {
                const a = result.data[i];
                mediaArray.push({
                    type: 'photo',
                    media: a.url,
                    caption: `Foto Slide Ke ${i + 1}`
                });
            }

            return bot.sendMediaGroup(chatId, mediaArray);
        } else {
            const video = result.data.find(e => e.type === "nowatermark_hd" || e.type === "nowatermark");
            if (video) {
                return bot.sendVideo(chatId, video.url, { caption: "TikTok Downloader BY LightSecret ✅" });
            }
        }
    } catch (e) {
        console.error(e);
        bot.sendMessage(chatId, "Terjadi kesalahan saat memproses permintaan.");
    }
});

bot.onText(/^(\.|\#|\/)brat$/, async (msg) => {
    const chatId = msg.chat.id;
    bot.sendMessage(chatId, `Format salah example /brat katakatabebas`);
  });
  
bot.onText(/\/brat (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const text = match[1];

    if (!text) {
        return bot.sendMessage(chatId, 'Contoh penggunaan: /brat teksnya');
    }

    try {
        const imageUrl = `https://kepolu-brat.hf.space/brat?q=${encodeURIComponent(text)}`;
        const tempFilePath = './temp_sticker.webp';
        const downloadFile = async (url, dest) => {
            const writer = fs.createWriteStream(dest);

            const response = await axios({
                url,
                method: 'GET',
                responseType: 'stream',
            });

            response.data.pipe(writer);

            return new Promise((resolve, reject) => {
                writer.on('finish', resolve);
                writer.on('error', reject);
            });
        };

        await downloadFile(imageUrl, tempFilePath);

        await bot.sendSticker(chatId, tempFilePath);

        await fs.promises.unlink(tempFilePath);
    } catch (error) {
        console.error(error.message || error);
        bot.sendMessage(chatId, 'Terjadi kesalahan saat membuat stiker. Pastikan teks valid atau coba lagi.');
    }
});

bot.onText(/\/tourl/, async (msg, match) => {
    const chatId = msg.chat.id;
    const isPrivateChat = msg.chat.type === 'private';

    if (msg.reply_to_message && msg.reply_to_message.photo) {
        try {
            const fileId = msg.reply_to_message.photo[msg.reply_to_message.photo.length - 1].file_id;
            const filePath = await bot.downloadFile(fileId, './temp');
            const fileBuffer = fs.readFileSync(filePath);
            
            const service = new ImageUploadService('pixhost.to');
            const { directLink } = await service.uploadFromBinary(fileBuffer, 'uploaded_image.png');
            const responseText = `Berikut adalah URL gambar Anda:\n${directLink}`;
            bot.sendMessage(chatId, responseText, { reply_to_message_id: msg.message_id });

            fs.unlinkSync(filePath);
        } catch (error) {
            const errorMessage = `Terjadi kesalahan: ${error.message}`;
            bot.sendMessage(chatId, errorMessage, { reply_to_message_id: msg.message_id });
        }
    } else {
       
        const errorText = isPrivateChat
            ? 'Harap balas pesan dengan gambar untuk mengubahnya menjadi URL.'
            : 'Perintah ini hanya berfungsi jika Anda membalas pesan dengan gambar.';
        bot.sendMessage(chatId, errorText, { reply_to_message_id: msg.message_id });
    }
});

bot.onText(/^(\.|\#|\/)play$/, async (msg) => {
    const chatId = msg.chat.id;
    bot.sendMessage(chatId, `format salah example /play bunga terakhir`);
  });
  
bot.onText(/\/play (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const query = match[1];

    if (!query) {
        return bot.sendMessage(chatId, 'Contoh penggunaan:\n\n/play Pulang - Wali Band');
    }

    try {
        const search = await yts(query);
        if (!search || search.all.length === 0) {
            return bot.sendMessage(chatId, 'Lagu yang Anda cari tidak ditemukan.');
        }

        const video = search.videos[0];
        const detail = `
🎵 **YouTube Audio Play** 🎶

✨ **Judul Lagu**: ${video.title}
👁️‍🗨️ **Penonton**: ${video.views}
🎤 **Pengarang**: ${video.author.name}
📅 **Diunggah**: ${video.ago}
🔗 **Tonton Selengkapnya**: [Klik Disini](${video.url})`;

        await bot.sendMessage(chatId, detail, { parse_mode: 'Markdown' });

        const stream = ytdl(video.url, { filter: 'audioonly' });

        bot.sendAudio(chatId, stream, { caption: 'Sekarang Memutar Musik' });

    } catch (error) {
        console.error('Error:', error.message);
        bot.sendMessage(chatId, 'Terjadi kesalahan saat memproses permintaan Anda.');
    }
});

// Respon ketika pengguna mengirim /domain
bot.onText(/\/domain/, (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString(); // Ubah ke string agar sesuai dengan settings.js

    if (userId === owner) {
        bot.sendMessage(chatId, `📍Domain:\n${domain}`);
    } else {
        bot.sendMessage(chatId, 'FITUR KHUSUS OWNER!!');
    }
});

bot.onText(/\/plta/, (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString(); // Ubah ke string agar sesuai dengan settings.js

    if (userId === owner) {
        bot.sendMessage(chatId, `📍Plta:\n${plta}`);
    } else {
        bot.sendMessage(chatId, 'FITUR KHUSUS OWNER!!');
    }
});

bot.onText(/\/pltc/, (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString(); // Ubah ke string agar sesuai dengan settings.js

    if (userId === owner) {
        bot.sendMessage(chatId, `📍Pltc:\n${pltc}`);
    } else {
        bot.sendMessage(chatId, 'FITUR KHUSUS OWNER!!');
    }
});

bot.onText(/^(\.|\#|\/)delsrv$/, async (msg) => {
    const chatId = msg.chat.id;
    bot.sendMessage(chatId, `Format salah example delsrv id`);
  });
bot.onText(/\/delsrv (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const srv = match[1].trim();

  const adminUsers = owner;
  const isAdmin = adminUsers.includes(String(msg.from.id));

  if (!isAdmin) {
    bot.sendMessage(
      chatId,
      "Fitur Khusus Owner!",
      {
        reply_markup: {
          inline_keyboard: [
            [{ text: "HUBUNGI ADMIN", url: "https://t.me/lightsecrett" }],
          ],
        },
      }
    );
    return;
  }

  if (!srv) {
    bot.sendMessage(
      chatId,
      "Mohon masukkan ID server yang ingin dihapus, contoh: /delsrv 1234"
    );
    return;
  }

  try {
    let f = await fetch(domain + "/api/application/servers/" + srv, {
      method: "DELETE",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
    });

    let res = f.ok ? { errors: null } : await f.json();

    if (res.errors) {
      bot.sendMessage(chatId, "SERVER TIDAK ADA");
    } else {
      bot.sendMessage(chatId, "SUCCESFULLY DELETE SERVER");
    }
  } catch (error) {
    console.error(error);
    bot.sendMessage(chatId, "Terjadi kesalahan saat menghapus server.");
  }
});

bot.onText(/^(\.|\#|\/)deluser$/, async (msg) => {
    const chatId = msg.chat.id;
    bot.sendMessage(chatId, `Format salah example delusr id yang akan di hapus`);
  });
  

bot.onText(/\/delusr(.*)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const usr = match[1].trim();

    const adminUsers = owner;
    const isAdmin = adminUsers.includes(String(msg.from.id));

    if (!isAdmin) {
        bot.sendMessage(chatId, 'Fitur Khusus Owner!', {
       reply_markup: {
          inline_keyboard: [
            [{ text: "HUBUNGI ADMIN", url: "https://t.me/lightsecrett" }],
          ],
        },
            }
        );
        return;
    }

    if (!usr) {
        bot.sendMessage(chatId, 'Mohon masukkan ID server yang ingin dihapus, contoh: /delusr 1');
        return;
    }

try {
        let f = await fetch(`${domain}/api/application/users/${usr}`, {
	            method: 'DELETE',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${plta}`
            }
        });

        let res = f.ok ? { errors: null } : await f.json();

        if (res.errors) {
            bot.sendMessage(chatId, 'USER NOT FOUND');
        } else {
            bot.sendMessage(chatId, 'SUCCESSFULLY DELETE THE USER');
        }
    } catch (error) {
        console.error(error);
        bot.sendMessage(chatId, 'Terjadi kesalahan saat menghapus server.');
    }
});

bot.onText(/\/listusr/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const adminUsers = owner;
    const isAdmin = adminUsers.includes(String(msg.from.id));
    if (!isAdmin) {
        bot.sendMessage(chatId, 'Fitur Khusus Owner!', {
          reply_markup: {
          inline_keyboard: [
            [{ text: "HUBUNGI ADMIN", url: "https://t.me/lightsecrett" }],
          ],
        },  
                       
            }
        );
        return;
    }
    let page = '1';
    try {
        let f = await fetch(`${domain}/api/application/users?page=${page}`, {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${plta}`
            }
        });
        let res = await f.json();
        let users = res.data;
        let messageText = "Berikut daftar users aktif yang dimiliki :\n\n";
        for (let user of users) {
            let u = user.attributes;
                messageText += `\x0aID Users: ${u.id}`
                messageText += `\x0aName Users: ${u.username}`;
            }
            
        messageText += `\x0aPage : ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
        messageText += `Total User : ${res.meta.pagination.count}`;
        bot.sendMessage(chatId, messageText);
    } catch (error) {
        console.error(error);
        bot.sendMessage(chatId, 'Terjadi kesalahan dalam memproses permintaan.');
    }
});

bot.onText(/\/listsrv/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  // Check if the user is the Owner
  const adminUsers = owner;
  const isAdmin = adminUsers.includes(String(msg.from.id));
  if (!isAdmin) {
    bot.sendMessage(
      chatId,
      "Fitur Khusus Owner!",
      {
        reply_markup: {
          inline_keyboard: [
            [{ text: "HUBUNGI ADMIN", url: "https://t.me/lightsecrett" }],
          ],
        },
      }
    );
    return;
  }
  let page = 1; // Mengubah penggunaan args[0] yang tidak didefinisikan sebelumnya
  try {
    let f = await fetch(`${domain}/api/application/servers?page=${page}`, {
      // Menggunakan backticks untuk string literal
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
    });
    let res = await f.json();
    let servers = res.data;
    let messageText = "Daftar server aktif yang dimiliki:\n\n";
    for (let server of servers) {
      let s = server.attributes;

      let f3 = await fetch(
        `${domain}/api/client/servers/${s.uuid.split("-")[0]}/resources`,
        {
          method: "GET",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: `Bearer ${pltc}`,
          },
        }
      );
      let data = await f3.json();
      let status = data.attributes ? data.attributes.current_state : s.status;

      messageText += `ID Server: ${s.id}\n`;
      messageText += `Nama Server: ${s.name}\n`;
      messageText += `Status: ${status}\n\n`;
    }

    bot.sendMessage(chatId, messageText);
  } catch (error) {
    console.error(error);
    bot.sendMessage(chatId, "Terjadi kesalahan dalam memproses permintaan.");
  }
});

bot.onText(/\/addprem (\d+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    const newPremiumId = match[1].toString();

    // Cek apakah pengirim adalah pemilik bot
    if (userId !== owner) {
        bot.sendMessage(chatId, "Fitur Khusus Owner");
        return;
    }

    try {
        // Baca file premiumUsers.json
        let premiumUsers = [];
        if (fs.existsSync(premiumUsersFile)) {
            premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
        }

        // Periksa apakah ID sudah ada dalam daftar premium
        if (premiumUsers.includes(newPremiumId)) {
            bot.sendMessage(chatId, `${newPremiumId} Sudah Di Addprem`);
            return;
        }

        // Tambahkan ID baru ke daftar premium
        premiumUsers.push(newPremiumId);
        fs.writeFileSync(premiumUsersFile, JSON.stringify(premiumUsers, null, 2));

        bot.sendMessage(chatId, `Sukses Add ${newPremiumId} Ke Premium`);
    } catch (error) {
        console.error("Error updating premiumUsers file:", error);
        bot.sendMessage(chatId, "Terjadi kesalahan saat memperbarui daftar premium.");
    }
});

function loadPremiumUsers() {
    try {
        const data = fs.readFileSync('premiumUsers.json', 'utf8');
        return JSON.parse(data);
    } catch (err) {
        return { premium: [] };
    }
}

const premiumFile = "premiumUsers.json";


// Fungsi untuk menyimpan daftar pengguna premium
const savePremiumUsers = (data) => {
    fs.writeFileSync(premiumFile, JSON.stringify(data, null, 2));
};

// Fungsi untuk menghapus user dari daftar premium
const removePremiumUser = (userId) => {
    let premiumUsers = loadPremiumUsers();
    const index = premiumUsers.indexOf(userId);
    if (index !== -1) {
        premiumUsers.splice(index, 1);
        savePremiumUsers(premiumUsers);
        return true;
    }
    return false;
};

// Event handler untuk perintah /delprem
bot.onText(/\/delprem (\d+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const admin = owner;
    const userId = msg.from.id;
    const targetId = match[1]; // ID yang ingin dihapus

    // Cek apakah user adalah owner
    if (userId.toString() !== admin) {
        return bot.sendMessage(chatId, "❌ Maaf, Anda tidak memiliki akses untuk menggunakan perintah ini.");
    }

    let premiumUsers = loadPremiumUsers();

    // Cek apakah user ada dalam daftar premium
    if (!premiumUsers.includes(targetId)) {
        return bot.sendMessage(chatId, `❌ User ID ${targetId} Tidak Di Temukan.`);
    }

    // Hapus user dari daftar premium
    if (removePremiumUser(targetId)) {
        bot.sendMessage(
            chatId,
            `✅ Sukses Menghapus User *${targetId}* Dari Premium `,
            { parse_mode: "Markdown" }
        );
    } else {
        bot.sendMessage(chatId, "⚠️ Terjadi kesalahan saat menghapus user premium.");
    }
});

bot.onText(/\/listprem/, (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const admin = owner;

    // Cek apakah yang menjalankan perintah adalah owner
    if (userId.toString() !== admin) {
        return bot.sendMessage(chatId, "Fitur Khusus Owner!");
    }

    // Baca file premiumUsers.json
    fs.readFile('premiumUsers.json', 'utf8', (err, data) => {
        if (err) {
            console.error("Error membaca file:", err);
            return bot.sendMessage(chatId, "⚠️ Terjadi kesalahan saat membaca daftar pengguna premium.");
        }

        let premiumUsers;
        try {
            premiumUsers = JSON.parse(data);
        } catch (e) {
            return bot.sendMessage(chatId, "⚠️ Format file premiumUsers.json tidak valid.");
        }

        // Cek apakah ada pengguna premium
        if (premiumUsers.length === 0) {
            return bot.sendMessage(chatId, "📌 *LIST USER PREMIUM*\n\nTidak ada pengguna premium.", { parse_mode: "Markdown" });
        }

        // Buat daftar user premium dalam format pesan
        const listMessage = premiumUsers
            .map((id, index) => `*${index + 1}.* [${id}](tg://user?id=${id})`)
            .join("\n");

        const message = `📌 *LIST USER PREMIUM*\n\n${listMessage}\n\n🔰 *Total:* ${premiumUsers.length} user`;

        bot.sendMessage(chatId, message, { parse_mode: "Markdown" });
    });
});

bot.onText(/\/1gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, "Anda Belum Menjadi Users Premium.", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "HUBUNGI ADMIN", url: "https://t.me/lightsecrett" }],
        ],
      },
    });
    return;
  }
  const t = text.split(",");
  if (t.length < 2) {
    bot.sendMessage(chatId, "Invalid format. Usage: /1gb namapanel,idtele");
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + "1gb";
  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = "1024";
  const cpu = "30";
  const disk = "1024";
  const spc =
    'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
  const email = `${username}@LIGHT.SECRET`;
  const akunlo = settings.pp;
  const password = `${username}9192`;
  let user;
  let server;
  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: "en",
        password: password,
      }),
    });
    const data = await response.json();
    if (data.errors) {
      if (
        data.errors[0].meta.rule === "unique" &&
        data.errors[0].meta.source_field === "email"
      ) {
        bot.sendMessage(
          chatId,
          "Email already exists. Please use a different email."
        );
      } else {
        bot.sendMessage(
          chatId,
          `Error: ${JSON.stringify(data.errors[0], null, 2)}`
        );
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        name: name,
        description: "",
        user: user.id,
        egg: parseInt(egg),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
        startup: spc,
        environment: {
          INST: "npm",
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          CMD_RUN: "npm start",
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu,
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1,
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: [],
        },
      }),
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(
      chatId,
      `BERIKUT DATA PANEL ANDA
NAMA: ${username}
EMAIL: ${email}
ID: ${user.id}
MEMORY: ${server.limits.memory === 0 ? "Unlimited" : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? "Unlimited" : server.limits.disk} MB
CPU: ${server.limits.cpu}%`
    );
    if (panelUrl) {
      bot.sendPhoto(u, panelUrl, {
        caption: `Hai @${u}

 DETAIL DATA PANEL ANDA :
👑 Login : ${domain}
💣 Username : ${user.username}
🔑 Password : ${password} 

📍 ᴄᴀᴛᴀᴛᴀɴ ᴘᴇɴᴛɪɴɢ:
    ᴡᴇʙ ᴊᴀɴɢᴀɴ ᴅɪ ʙᴜᴀᴛ ᴅᴅᴏs
    ᴛᴜᴛᴜᴘɪ ᴅᴏᴍᴀɪɴ ᴋᴇᴛɪᴋᴀ ᴅɪ ss
    ᴅᴏᴍᴀɪɴ ᴊᴀɴɢᴀɴ ᴅɪ sᴇʙᴀʀ
    ᴍᴏʜᴏɴ ᴘᴇʀʜᴀᴛɪᴀɴ
    ALL TRANSAKSI NO REFFUND
    EXPIRED 1 BULAN PENUH
    GARANSI 10 DAY 1 KALI CLAIM
    JANGAN LUPA SS DONE. 
`,
      });
      bot.sendMessage(
        chatId,
        "Data panel berhasil dikirim ke ID Telegram yang dimaksud."
      );
    }
  } else {
    bot.sendMessage(chatId, "Gagal membuat data panel. Silakan coba lagi.");
  }
});

bot.onText(/\/2gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, "Anda Belum Menjadi Users Premium.", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "HUBUNGI ADMIN", url: "https://t.me/lightsecrett" }],
        ],
      },
    });
    return;
  }
  const t = text.split(",");
  if (t.length < 2) {
    bot.sendMessage(chatId, "Invalid format. Usage: /2gb namapanel,idtele");
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + "2gb";
  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = "2048";
  const cpu = "60";
  const disk = "2048";
  const spc =
    'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
  const email = `${username}@LIGHT.SECRET`;
  const akunlo = settings.pp;
  const password = `${username}9192`;
  let user;
  let server;
  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: "en",
        password: password,
      }),
    });
    const data = await response.json();
    if (data.errors) {
      if (
        data.errors[0].meta.rule === "unique" &&
        data.errors[0].meta.source_field === "email"
      ) {
        bot.sendMessage(
          chatId,
          "Email already exists. Please use a different email."
        );
      } else {
        bot.sendMessage(
          chatId,
          `Error: ${JSON.stringify(data.errors[0], null, 2)}`
        );
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        name: name,
        description: "",
        user: user.id,
        egg: parseInt(egg),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
        startup: spc,
        environment: {
          INST: "npm",
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          CMD_RUN: "npm start",
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu,
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1,
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: [],
        },
      }),
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(
      chatId,
      `BERIKUT DATA PANEL ANDA
NAMA: ${username}
EMAIL: ${email}
ID: ${user.id}
MEMORY: ${server.limits.memory === 0 ? "Unlimited" : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? "Unlimited" : server.limits.disk} MB
CPU: ${server.limits.cpu}%`
    );
    if (panelUrl) {
      bot.sendPhoto(u, panelUrl, {
        caption: `Hai @${u}

 DETAIL DATA PANEL ANDA :
👑 Login : ${domain}
💣 Username : ${user.username}
🔑 Password : ${password} 

📍 ᴄᴀᴛᴀᴛᴀɴ ᴘᴇɴᴛɪɴɢ:
    ᴡᴇʙ ᴊᴀɴɢᴀɴ ᴅɪ ʙᴜᴀᴛ ᴅᴅᴏs
    ᴛᴜᴛᴜᴘɪ ᴅᴏᴍᴀɪɴ ᴋᴇᴛɪᴋᴀ ᴅɪ ss
    ᴅᴏᴍᴀɪɴ ᴊᴀɴɢᴀɴ ᴅɪ sᴇʙᴀʀ
    ᴍᴏʜᴏɴ ᴘᴇʀʜᴀᴛɪᴀɴ
    ALL TRANSAKSI NO REFFUND
    EXPIRED 1 BULAN PENUH
    GARANSI 10 DAY 1 KALI CLAIM
    JANGAN LUPA SS DONE. 
`,
      });
      bot.sendMessage(
        chatId,
        "Data panel berhasil dikirim ke ID Telegram yang dimaksud."
      );
    }
  } else {
    bot.sendMessage(chatId, "Gagal membuat data panel. Silakan coba lagi.");
  }
});

bot.onText(/\/3gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, "Anda Belum Menjadi Users Premium.", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "HUBUNGI ADMIN", url: "https://t.me/lightsecrett" }],
        ],
      },
    });
    return;
  }
  const t = text.split(",");
  if (t.length < 2) {
    bot.sendMessage(chatId, "Invalid format. Usage: /3gb namapanel,idtele");
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + "3gb";
  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = "3048";
  const cpu = "90";
  const disk = "3048";
  const spc =
    'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
  const email = `${username}@LIGHT.SECRET`;
  const akunlo = settings.pp;
  const password = `${username}842`;
  let user;
  let server;
  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: "en",
        password: password,
      }),
    });
    const data = await response.json();
    if (data.errors) {
      if (
        data.errors[0].meta.rule === "unique" &&
        data.errors[0].meta.source_field === "email"
      ) {
        bot.sendMessage(
          chatId,
          "Email already exists. Please use a different email."
        );
      } else {
        bot.sendMessage(
          chatId,
          `Error: ${JSON.stringify(data.errors[0], null, 2)}`
        );
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        name: name,
        description: "",
        user: user.id,
        egg: parseInt(egg),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
        startup: spc,
        environment: {
          INST: "npm",
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          CMD_RUN: "npm start",
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu,
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1,
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: [],
        },
      }),
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(
      chatId,
      `BERIKUT DATA PANEL ANDA
NAMA: ${username}
EMAIL: ${email}
ID: ${user.id}
MEMORY: ${server.limits.memory === 0 ? "Unlimited" : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? "Unlimited" : server.limits.disk} MB
CPU: ${server.limits.cpu}%`
    );
    if (panelUrl) {
      bot.sendPhoto(u, panelUrl, {
        caption: `Hai @${u}

 DETAIL DATA PANEL ANDA :
👑 Login : ${domain}
💣 Username : ${user.username}
🔑 Password : ${password} 

📍 ᴄᴀᴛᴀᴛᴀɴ ᴘᴇɴᴛɪɴɢ:
    ᴡᴇʙ ᴊᴀɴɢᴀɴ ᴅɪ ʙᴜᴀᴛ ᴅᴅᴏs
    ᴛᴜᴛᴜᴘɪ ᴅᴏᴍᴀɪɴ ᴋᴇᴛɪᴋᴀ ᴅɪ ss
    ᴅᴏᴍᴀɪɴ ᴊᴀɴɢᴀɴ ᴅɪ sᴇʙᴀʀ
    ᴍᴏʜᴏɴ ᴘᴇʀʜᴀᴛɪᴀɴ
    ALL TRANSAKSI NO REFFUND
    EXPIRED 1 BULAN PENUH
    GARANSI 10 DAY 1 KALI CLAIM
    JANGAN LUPA SS DONE. 
`,
      });
      bot.sendMessage(
        chatId,
        "Data panel berhasil dikirim ke ID Telegram yang dimaksud."
      );
    }
  } else {
    bot.sendMessage(chatId, "Gagal membuat data panel. Silakan coba lagi.");
  }
});

bot.onText(/\/4gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, "Anda Belum Menjadi Users Premium.", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "HUBUNGI ADMIN", url: "https://t.me/lightsecrett" }],
        ],
      },
    });
    return;
  }
  const t = text.split(",");
  if (t.length < 2) {
    bot.sendMessage(chatId, "Invalid format. Usage: /4gb namapanel,idtele");
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + "4gb";
  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = "4048";
  const cpu = "120";
  const disk = "4048";
  const spc =
    'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
  const email = `${username}@LIGHT.SECRET`;
  const akunlo = settings.pp;
  const password = `${username}9192`;
  let user;
  let server;
  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: "en",
        password: password,
      }),
    });
    const data = await response.json();
    if (data.errors) {
      if (
        data.errors[0].meta.rule === "unique" &&
        data.errors[0].meta.source_field === "email"
      ) {
        bot.sendMessage(
          chatId,
          "Email already exists. Please use a different email."
        );
      } else {
        bot.sendMessage(
          chatId,
          `Error: ${JSON.stringify(data.errors[0], null, 2)}`
        );
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        name: name,
        description: "",
        user: user.id,
        egg: parseInt(egg),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
        startup: spc,
        environment: {
          INST: "npm",
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          CMD_RUN: "npm start",
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu,
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1,
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: [],
        },
      }),
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(
      chatId,
      `BERIKUT DATA PANEL ANDA
NAMA: ${username}
EMAIL: ${email}
ID: ${user.id}
MEMORY: ${server.limits.memory === 0 ? "Unlimited" : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? "Unlimited" : server.limits.disk} MB
CPU: ${server.limits.cpu}%`
    );
    if (panelUrl) {
      bot.sendPhoto(u, panelUrl, {
        caption: `Hai @${u}

 DETAIL DATA PANEL ANDA :
👑 Login : ${domain}
💣 Username : ${user.username}
🔑 Password : ${password} 

📍 ᴄᴀᴛᴀᴛᴀɴ ᴘᴇɴᴛɪɴɢ:
    ᴡᴇʙ ᴊᴀɴɢᴀɴ ᴅɪ ʙᴜᴀᴛ ᴅᴅᴏs
    ᴛᴜᴛᴜᴘɪ ᴅᴏᴍᴀɪɴ ᴋᴇᴛɪᴋᴀ ᴅɪ ss
    ᴅᴏᴍᴀɪɴ ᴊᴀɴɢᴀɴ ᴅɪ sᴇʙᴀʀ
    ᴍᴏʜᴏɴ ᴘᴇʀʜᴀᴛɪᴀɴ
    ALL TRANSAKSI NO REFFUND
    EXPIRED 1 BULAN PENUH
    GARANSI 10 DAY 1 KALI CLAIM
    JANGAN LUPA SS DONE. 
`,
      });
      bot.sendMessage(
        chatId,
        "Data panel berhasil dikirim ke ID Telegram yang dimaksud."
      );
    }
  } else {
    bot.sendMessage(chatId, "Gagal membuat data panel. Silakan coba lagi.");
  }
});

bot.onText(/\/5gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, "Anda Belum Menjadi Users Premium.", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "HUBUNGI ADMIN", url: "https://t.me/lightsecrett" }],
        ],
      },
    });
    return;
  }
  const t = text.split(",");
  if (t.length < 2) {
    bot.sendMessage(chatId, "Invalid format. Usage: /5gb namapanel,idtele");
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + "5gb";
  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = "5048";
  const cpu = "150";
  const disk = "5048";
  const spc =
    'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
  const email = `${username}@LIGHT.SECRET`;
  const akunlo = settings.pp;
  const password = `${username}6052`;
  let user;
  let server;
  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: "en",
        password: password,
      }),
    });
    const data = await response.json();
    if (data.errors) {
      if (
        data.errors[0].meta.rule === "unique" &&
        data.errors[0].meta.source_field === "email"
      ) {
        bot.sendMessage(
          chatId,
          "Email already exists. Please use a different email."
        );
      } else {
        bot.sendMessage(
          chatId,
          `Error: ${JSON.stringify(data.errors[0], null, 2)}`
        );
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        name: name,
        description: "",
        user: user.id,
        egg: parseInt(egg),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
        startup: spc,
        environment: {
          INST: "npm",
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          CMD_RUN: "npm start",
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu,
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1,
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: [],
        },
      }),
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(
      chatId,
      `BERIKUT DATA PANEL ANDA
NAMA: ${username}
EMAIL: ${email}
ID: ${user.id}
MEMORY: ${server.limits.memory === 0 ? "Unlimited" : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? "Unlimited" : server.limits.disk} MB
CPU: ${server.limits.cpu}%`
    );
    if (panelUrl) {
      bot.sendPhoto(u, panelUrl, {
        caption: `Hai @${u}

 DETAIL DATA PANEL ANDA :
👑 Login : ${domain}
💣 Username : ${user.username}
🔑 Password : ${password} 

📍 ᴄᴀᴛᴀᴛᴀɴ ᴘᴇɴᴛɪɴɢ:
    ᴡᴇʙ ᴊᴀɴɢᴀɴ ᴅɪ ʙᴜᴀᴛ ᴅᴅᴏs
    ᴛᴜᴛᴜᴘɪ ᴅᴏᴍᴀɪɴ ᴋᴇᴛɪᴋᴀ ᴅɪ ss
    ᴅᴏᴍᴀɪɴ ᴊᴀɴɢᴀɴ ᴅɪ sᴇʙᴀʀ
    ᴍᴏʜᴏɴ ᴘᴇʀʜᴀᴛɪᴀɴ
    ALL TRANSAKSI NO REFFUND
    EXPIRED 1 BULAN PENUH
    GARANSI 10 DAY 1 KALI CLAIM
    JANGAN LUPA SS DONE. 
`,
      });
      bot.sendMessage(
        chatId,
        "Data panel berhasil dikirim ke ID Telegram yang dimaksud."
      );
    }
  } else {
    bot.sendMessage(chatId, "Gagal membuat data panel. Silakan coba lagi.");
  }
});

bot.onText(/\/6gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, "Anda Belum Menjadi Users Premium.", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "HUBUNGI ADMIN", url: "https://t.me/lightsecrett" }],
        ],
      },
    });
    return;
  }
  const t = text.split(",");
  if (t.length < 2) {
    bot.sendMessage(chatId, "Invalid format. Usage: /6gb namapanel,idtele");
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + "6gb";
  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = "6048";
  const cpu = "180";
  const disk = "6048";
  const spc =
    'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
  const email = `${username}@LIGHT.SECRET`;
  const akunlo = settings.pp;
  const password = `${username}9192`;
  let user;
  let server;
  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: "en",
        password: password,
      }),
    });
    const data = await response.json();
    if (data.errors) {
      if (
        data.errors[0].meta.rule === "unique" &&
        data.errors[0].meta.source_field === "email"
      ) {
        bot.sendMessage(
          chatId,
          "Email already exists. Please use a different email."
        );
      } else {
        bot.sendMessage(
          chatId,
          `Error: ${JSON.stringify(data.errors[0], null, 2)}`
        );
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        name: name,
        description: "",
        user: user.id,
        egg: parseInt(egg),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
        startup: spc,
        environment: {
          INST: "npm",
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          CMD_RUN: "npm start",
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu,
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1,
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: [],
        },
      }),
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(
      chatId,
      `BERIKUT DATA PANEL ANDA
NAMA: ${username}
EMAIL: ${email}
ID: ${user.id}
MEMORY: ${server.limits.memory === 0 ? "Unlimited" : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? "Unlimited" : server.limits.disk} MB
CPU: ${server.limits.cpu}%`
    );
    if (panelUrl) {
      bot.sendPhoto(u, panelUrl, {
        caption: `Hai @${u}

 DETAIL DATA PANEL ANDA :
👑 Login : ${domain}
💣 Username : ${user.username}
🔑 Password : ${password} 

📍 ᴄᴀᴛᴀᴛᴀɴ ᴘᴇɴᴛɪɴɢ:
    ᴡᴇʙ ᴊᴀɴɢᴀɴ ᴅɪ ʙᴜᴀᴛ ᴅᴅᴏs
    ᴛᴜᴛᴜᴘɪ ᴅᴏᴍᴀɪɴ ᴋᴇᴛɪᴋᴀ ᴅɪ ss
    ᴅᴏᴍᴀɪɴ ᴊᴀɴɢᴀɴ ᴅɪ sᴇʙᴀʀ
    ᴍᴏʜᴏɴ ᴘᴇʀʜᴀᴛɪᴀɴ
    ALL TRANSAKSI NO REFFUND
    EXPIRED 1 BULAN PENUH
    GARANSI 10 DAY 1 KALI CLAIM
    JANGAN LUPA SS DONE. 
`,
      });
      bot.sendMessage(
        chatId,
        "Data panel berhasil dikirim ke ID Telegram yang dimaksud."
      );
    }
  } else {
    bot.sendMessage(chatId, "Gagal membuat data panel. Silakan coba lagi.");
  }
});

bot.onText(/\/7gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, "Anda Belum Menjadi Users Premium.", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "HUBUNGI ADMIN", url: "https://t.me/lightsecrett" }],
        ],
      },
    });
    return;
  }
  const t = text.split(",");
  if (t.length < 2) {
    bot.sendMessage(chatId, "Invalid format. Usage: /7gb namapanel,idtele");
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + "7gb";
  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = "7048";
  const cpu = "210";
  const disk = "7048";
  const spc =
    'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
  const email = `${username}@LIGHT.SECRET`;
  const akunlo = settings.pp;
  const password = `${username}84852`;
  let user;
  let server;
  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: "en",
        password: password,
      }),
    });
    const data = await response.json();
    if (data.errors) {
      if (
        data.errors[0].meta.rule === "unique" &&
        data.errors[0].meta.source_field === "email"
      ) {
        bot.sendMessage(
          chatId,
          "Email already exists. Please use a different email."
        );
      } else {
        bot.sendMessage(
          chatId,
          `Error: ${JSON.stringify(data.errors[0], null, 2)}`
        );
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        name: name,
        description: "",
        user: user.id,
        egg: parseInt(egg),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
        startup: spc,
        environment: {
          INST: "npm",
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          CMD_RUN: "npm start",
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu,
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1,
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: [],
        },
      }),
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(
      chatId,
      `BERIKUT DATA PANEL ANDA
NAMA: ${username}
EMAIL: ${email}
ID: ${user.id}
MEMORY: ${server.limits.memory === 0 ? "Unlimited" : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? "Unlimited" : server.limits.disk} MB
CPU: ${server.limits.cpu}%`
    );
    if (panelUrl) {
      bot.sendPhoto(u, panelUrl, {
        caption: `Hai @${u}

 DETAIL DATA PANEL ANDA :
👑 Login : ${domain}
💣 Username : ${user.username}
🔑 Password : ${password} 

📍 ᴄᴀᴛᴀᴛᴀɴ ᴘᴇɴᴛɪɴɢ:
    ᴡᴇʙ ᴊᴀɴɢᴀɴ ᴅɪ ʙᴜᴀᴛ ᴅᴅᴏs
    ᴛᴜᴛᴜᴘɪ ᴅᴏᴍᴀɪɴ ᴋᴇᴛɪᴋᴀ ᴅɪ ss
    ᴅᴏᴍᴀɪɴ ᴊᴀɴɢᴀɴ ᴅɪ sᴇʙᴀʀ
    ᴍᴏʜᴏɴ ᴘᴇʀʜᴀᴛɪᴀɴ
    ALL TRANSAKSI NO REFFUND
    EXPIRED 1 BULAN PENUH
    GARANSI 10 DAY 1 KALI CLAIM
    JANGAN LUPA SS DONE. 
`,
      });
      bot.sendMessage(
        chatId,
        "Data panel berhasil dikirim ke ID Telegram yang dimaksud."
      );
    }
  } else {
    bot.sendMessage(chatId, "Gagal membuat data panel. Silakan coba lagi.");
  }
});

bot.onText(/\/8gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, "Anda Belum Menjadi Users Premium.", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "HUBUNGI ADMIN", url: "https://t.me/lightsecrett" }],
        ],
      },
    });
    return;
  }
  const t = text.split(",");
  if (t.length < 2) {
    bot.sendMessage(chatId, "Invalid format. Usage: /8gb namapanel,idtele");
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + "8gb";
  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = "8048";
  const cpu = "240";
  const disk = "8048";
  const spc =
    'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
  const email = `${username}@LIGHT.SECRET`;
  const akunlo = settings.pp;
  const password = `${username}2049`;
  let user;
  let server;
  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: "en",
        password: password,
      }),
    });
    const data = await response.json();
    if (data.errors) {
      if (
        data.errors[0].meta.rule === "unique" &&
        data.errors[0].meta.source_field === "email"
      ) {
        bot.sendMessage(
          chatId,
          "Email already exists. Please use a different email."
        );
      } else {
        bot.sendMessage(
          chatId,
          `Error: ${JSON.stringify(data.errors[0], null, 2)}`
        );
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        name: name,
        description: "",
        user: user.id,
        egg: parseInt(egg),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
        startup: spc,
        environment: {
          INST: "npm",
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          CMD_RUN: "npm start",
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu,
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1,
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: [],
        },
      }),
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(
      chatId,
      `BERIKUT DATA PANEL ANDA
NAMA: ${username}
EMAIL: ${email}
ID: ${user.id}
MEMORY: ${server.limits.memory === 0 ? "Unlimited" : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? "Unlimited" : server.limits.disk} MB
CPU: ${server.limits.cpu}%`
    );
    if (panelUrl) {
      bot.sendPhoto(u, panelUrl, {
        caption: `Hai @${u}

 DETAIL DATA PANEL ANDA :
👑 Login : ${domain}
💣 Username : ${user.username}
🔑 Password : ${password} 

📍 ᴄᴀᴛᴀᴛᴀɴ ᴘᴇɴᴛɪɴɢ:
    ᴡᴇʙ ᴊᴀɴɢᴀɴ ᴅɪ ʙᴜᴀᴛ ᴅᴅᴏs
    ᴛᴜᴛᴜᴘɪ ᴅᴏᴍᴀɪɴ ᴋᴇᴛɪᴋᴀ ᴅɪ ss
    ᴅᴏᴍᴀɪɴ ᴊᴀɴɢᴀɴ ᴅɪ sᴇʙᴀʀ
    ᴍᴏʜᴏɴ ᴘᴇʀʜᴀᴛɪᴀɴ
    ALL TRANSAKSI NO REFFUND
    EXPIRED 1 BULAN PENUH
    GARANSI 10 DAY 1 KALI CLAIM
    JANGAN LUPA SS DONE. 
`,
      });
      bot.sendMessage(
        chatId,
        "Data panel berhasil dikirim ke ID Telegram yang dimaksud."
      );
    }
  } else {
    bot.sendMessage(chatId, "Gagal membuat data panel. Silakan coba lagi.");
  }
});

bot.onText(/\/9gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, "Anda Belum Menjadi Users Premium.", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "HUBUNGI ADMIN", url: "https://t.me/lightsecrett" }],
        ],
      },
    });
    return;
  }
  const t = text.split(",");
  if (t.length < 2) {
    bot.sendMessage(chatId, "Invalid format. Usage: /9gb namapanel,idtele");
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + "9gb";
  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = "9048";
  const cpu = "270";
  const disk = "9048";
  const spc =
    'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
  const email = `${username}@LIGHT.SECRET`;
  const akunlo = settings.pp;
  const password = `${username}8574`;
  let user;
  let server;
  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: "en",
        password: password,
      }),
    });
    const data = await response.json();
    if (data.errors) {
      if (
        data.errors[0].meta.rule === "unique" &&
        data.errors[0].meta.source_field === "email"
      ) {
        bot.sendMessage(
          chatId,
          "Email already exists. Please use a different email."
        );
      } else {
        bot.sendMessage(
          chatId,
          `Error: ${JSON.stringify(data.errors[0], null, 2)}`
        );
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        name: name,
        description: "",
        user: user.id,
        egg: parseInt(egg),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
        startup: spc,
        environment: {
          INST: "npm",
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          CMD_RUN: "npm start",
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu,
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1,
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: [],
        },
      }),
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(
      chatId,
      `BERIKUT DATA PANEL ANDA
NAMA: ${username}
EMAIL: ${email}
ID: ${user.id}
MEMORY: ${server.limits.memory === 0 ? "Unlimited" : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? "Unlimited" : server.limits.disk} MB
CPU: ${server.limits.cpu}%`
    );
    if (panelUrl) {
      bot.sendPhoto(u, panelUrl, {
        caption: `Hai @${u}

 DETAIL DATA PANEL ANDA :
👑 Login : ${domain}
💣 Username : ${user.username}
🔑 Password : ${password} 

📍 ᴄᴀᴛᴀᴛᴀɴ ᴘᴇɴᴛɪɴɢ:
    ᴡᴇʙ ᴊᴀɴɢᴀɴ ᴅɪ ʙᴜᴀᴛ ᴅᴅᴏs
    ᴛᴜᴛᴜᴘɪ ᴅᴏᴍᴀɪɴ ᴋᴇᴛɪᴋᴀ ᴅɪ ss
    ᴅᴏᴍᴀɪɴ ᴊᴀɴɢᴀɴ ᴅɪ sᴇʙᴀʀ
    ᴍᴏʜᴏɴ ᴘᴇʀʜᴀᴛɪᴀɴ
    ALL TRANSAKSI NO REFFUND
    EXPIRED 1 BULAN PENUH
    GARANSI 10 DAY 1 KALI CLAIM
    JANGAN LUPA SS DONE. 
`,
      });
      bot.sendMessage(
        chatId,
        "Data panel berhasil dikirim ke ID Telegram yang dimaksud."
      );
    }
  } else {
    bot.sendMessage(chatId, "Gagal membuat data panel. Silakan coba lagi.");
  }
});

bot.onText(/\/10gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, "Anda Belum Menjadi Users Premium.", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "HUBUNGI ADMIN", url: "https://t.me/lightsecrett" }],
        ],
      },
    });
    return;
  }
  const t = text.split(",");
  if (t.length < 2) {
    bot.sendMessage(chatId, "Invalid format. Usage: /10gb namapanel,idtele");
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + "10gb";
  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = "10048";
  const cpu = "300";
  const disk = "10048";
  const spc =
    'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
  const email = `${username}@LIGHT.SECRET`;
  const akunlo = settings.pp;
  const password = `${username}5068`;
  let user;
  let server;
  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: "en",
        password: password,
      }),
    });
    const data = await response.json();
    if (data.errors) {
      if (
        data.errors[0].meta.rule === "unique" &&
        data.errors[0].meta.source_field === "email"
      ) {
        bot.sendMessage(
          chatId,
          "Email already exists. Please use a different email."
        );
      } else {
        bot.sendMessage(
          chatId,
          `Error: ${JSON.stringify(data.errors[0], null, 2)}`
        );
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        name: name,
        description: "",
        user: user.id,
        egg: parseInt(egg),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
        startup: spc,
        environment: {
          INST: "npm",
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          CMD_RUN: "npm start",
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu,
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1,
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: [],
        },
      }),
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(
      chatId,
      `BERIKUT DATA PANEL ANDA
NAMA: ${username}
EMAIL: ${email}
ID: ${user.id}
MEMORY: ${server.limits.memory === 0 ? "Unlimited" : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? "Unlimited" : server.limits.disk} MB
CPU: ${server.limits.cpu}%`
    );
    if (panelUrl) {
      bot.sendPhoto(u, panelUrl, {
        caption: `Hai @${u}

 DETAIL DATA PANEL ANDA :
👑 Login : ${domain}
💣 Username : ${user.username}
🔑 Password : ${password} 

📍 ᴄᴀᴛᴀᴛᴀɴ ᴘᴇɴᴛɪɴɢ:
    ᴡᴇʙ ᴊᴀɴɢᴀɴ ᴅɪ ʙᴜᴀᴛ ᴅᴅᴏs
    ᴛᴜᴛᴜᴘɪ ᴅᴏᴍᴀɪɴ ᴋᴇᴛɪᴋᴀ ᴅɪ ss
    ᴅᴏᴍᴀɪɴ ᴊᴀɴɢᴀɴ ᴅɪ sᴇʙᴀʀ
    ᴍᴏʜᴏɴ ᴘᴇʀʜᴀᴛɪᴀɴ
    ALL TRANSAKSI NO REFFUND
    EXPIRED 1 BULAN PENUH
    GARANSI 10 DAY 1 KALI CLAIM
    JANGAN LUPA SS DONE. 
`,
      });
      bot.sendMessage(
        chatId,
        "Data panel berhasil dikirim ke ID Telegram yang dimaksud."
      );
    }
  } else {
    bot.sendMessage(chatId, "Gagal membuat data panel. Silakan coba lagi.");
  }
});

bot.onText(/\/unli (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, "Anda Belum Menjadi Users Premium.", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "HUBUNGI ADMIN", url: "https://t.me/lightsecrett" }],
        ],
      },
    });
    return;
  }
  const t = text.split(",");
  if (t.length < 2) {
    bot.sendMessage(chatId, "Invalid format. Usage: /unli namapanel,idtele");
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + "unli";
  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = "0";
  const cpu = "0";
  const disk = "0";
  const spc =
    'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
  const email = `${username}@LIGHT.SECRET`;
  const akunlo = settings.pp;
  const password = `${username}910292`;
  let user;
  let server;
  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: "en",
        password: password,
      }),
    });
    const data = await response.json();
    if (data.errors) {
      if (
        data.errors[0].meta.rule === "unique" &&
        data.errors[0].meta.source_field === "email"
      ) {
        bot.sendMessage(
          chatId,
          "Email already exists. Please use a different email."
        );
      } else {
        bot.sendMessage(
          chatId,
          `Error: ${JSON.stringify(data.errors[0], null, 2)}`
        );
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        name: name,
        description: "",
        user: user.id,
        egg: parseInt(egg),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
        startup: spc,
        environment: {
          INST: "npm",
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          CMD_RUN: "npm start",
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu,
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1,
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: [],
        },
      }),
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(
      chatId,
      `BERIKUT DATA PANEL ANDA
NAMA: ${username}
EMAIL: ${email}
ID: ${user.id}
MEMORY: ${server.limits.memory === 0 ? "Unlimited" : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? "Unlimited" : server.limits.disk} MB
CPU: ${server.limits.cpu}%`
    );
    if (panelUrl) {
      bot.sendPhoto(u, panelUrl, {
        caption: `Hai @${u}

 DETAIL DATA PANEL ANDA :
👑 Login : ${domain}
💣 Username : ${user.username}
🔑 Password : ${password} 

📍 ᴄᴀᴛᴀᴛᴀɴ ᴘᴇɴᴛɪɴɢ:
    ᴡᴇʙ ᴊᴀɴɢᴀɴ ᴅɪ ʙᴜᴀᴛ ᴅᴅᴏs
    ᴛᴜᴛᴜᴘɪ ᴅᴏᴍᴀɪɴ ᴋᴇᴛɪᴋᴀ ᴅɪ ss
    ᴅᴏᴍᴀɪɴ ᴊᴀɴɢᴀɴ ᴅɪ sᴇʙᴀʀ
    ᴍᴏʜᴏɴ ᴘᴇʀʜᴀᴛɪᴀɴ
    ALL TRANSAKSI NO REFFUND
    EXPIRED 1 BULAN PENUH
    GARANSI 10 DAY 1 KALI CLAIM
    JANGAN LUPA SS DONE. 
`,
      });
      bot.sendMessage(
        chatId,
        "Data panel berhasil dikirim ke ID Telegram yang dimaksud."
      );
    }
  } else {
    bot.sendMessage(chatId, "Gagal membuat data panel. Silakan coba lagi.");
  }
});

// ─── Fungsi untuk random string aman ──────────────
function getRandom(length = 3) {
  return crypto.randomBytes(length).toString('hex');
}

// ─── Command: /hbpanel atau /hackbackpanel ─────────────────
bot.onText(/^\/(?:hbpanel|hackbackpanel) (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const fromId = msg.from.id.toString();

  // ─── Validasi Akses ─────────────────────────────
  const isOwner = fromId === owner.toString();
  const isPremium = Array.isArray(premiumUsers) && premiumUsers.map(String).includes(fromId);
  if (!isOwner && !isPremium) {
    return bot.sendMessage(
      chatId,
      `❌ 𝗙𝗶𝘁𝘂𝗿 𝗶𝗻𝗶 𝗵𝗮𝗻𝘆𝗮 𝘂𝗻𝘁𝘂𝗸 𝗢𝘄𝗻𝗲𝗿 (${ownerName}) 𝗱𝗮𝗻 𝗨𝘀𝗲𝗿 𝗣𝗿𝗲𝗺𝗶𝘂𝗺.`,
    );
  }

  // ─── Parsing Argumen ────────────────────────────
  const text = (match && match[1]) ? match[1].trim() : '';
  const parts = text.split("|");
  if (parts.length < 2) {
    return bot.sendMessage(
      chatId,
      `❗ 𝗙𝗼𝗿𝗺𝗮𝘁 𝘀𝗮𝗹𝗮𝗵.\n\n𝗚𝘂𝗻𝗮𝗸𝗮𝗻:\n/hbpanel ipvps|pwvps 𝗮𝘁𝗮𝘂 /hackbackpanel ipvps|pwvps\n\n𝗖𝗼𝗻𝘁𝗼𝗵:\n/hbpanel 1.2.3.4|rootpass`
    );
  }

  // ─── Data Server ────────────────────────────────
  const ipvps = parts[0].trim();
  const passwd = parts[1].trim();

  await bot.sendMessage(
    chatId,
    "⏳ 𝗠𝗲𝗻𝗴𝗵𝘂𝗯𝘂𝗻𝗴𝗸𝗮𝗻 𝗸𝗲 𝘀𝗲𝗿𝘃𝗲𝗿... 𝗠𝗼𝗵𝗼𝗻 𝘁𝘂𝗻𝗴𝗴𝘂",
  );

  // ─── Random Akun Aman ───────────────────────────
  const newuser = "lightsecret" + getRandom();
  const newpw = "lightsecret" + getRandom();

  // ─── Koneksi SSH ────────────────────────────────
  const connSettings = {
    host: ipvps,
    port: 22,
    username: 'root',
    password: passwd
  };

  const command = `bash <(curl -s https://raw.githubusercontent.com/Bangsano/Autoinstaller-Theme-Pterodactyl/refs/heads/main/install.sh)`;
  const conn = new Client();

  // ─── Saat Koneksi Siap ──────────────────────────
  conn.on('ready', () => {
    console.log('SSH ready — menjalankan installer');
    conn.exec(command, (err, stream) => {
      if (err) {
        console.error('Exec error:', err);
        bot.sendMessage(
          chatId,
          `❌ 𝗚𝗮𝗴𝗮𝗹 𝗺𝗲𝗻𝗷𝗮𝗹𝗮𝗻𝗸𝗮𝗻 𝗶𝗻𝘀𝘁𝗮𝗹𝗹𝗲𝗿.\n\n📌 𝗗𝗲𝘁𝗮𝗶𝗹: ${err.message}`
        );
        conn.end();
        return;
      }

      // ─── Setelah Installer Selesai ───────────────
      stream.on('close', async () => {
        const teks = `✅ 𝗛𝗮𝗰𝗸𝗯𝗮𝗰𝗸 𝗣𝗮𝗻𝗲𝗹 𝗕𝗲𝗿𝗵𝗮𝘀𝗶𝗹!\n\n𝗔𝗸𝘂𝗻 𝗔𝗱𝗺𝗶𝗻 𝗣𝗮𝗻𝗲𝗹:\n\n𝗨𝘀𝗲𝗿𝗻𝗮𝗺𝗲: ${newuser}\n𝗣𝗮𝘀𝘀𝘄𝗼𝗿𝗱: ${newpw}\n\nSilakan lanjutkan pengaturan melalui panel yang telah diinstal.`;
        try { await bot.sendMessage(chatId, teks); } catch(e){}
        conn.end();
      });

      // ─── Pembacaan Log Output ────────────────────
      stream.on('data', (data) => {
        const out = data.toString();
        console.log('[STDOUT]', out);

        // tanggapi prompt yang biasa muncul
        try {
          if (out.includes('Enter username') || /enter username/i.test(out) || /username:/i.test(out))
            stream.write(`${newuser}\n`);
          if (out.includes('Enter password') || /enter password/i.test(out) || /password:/i.test(out))
            stream.write(`${newpw}\n`);
          if (out.includes('(y/N)') || /y\/n/i.test(out)) stream.write('y\n');
          if (out.includes('Input 0-6') || /input 0-6/i.test(out)) stream.write('0\n');
        } catch (e) {
          // jika stream sudah tertutup, abaikan
        }
      });

      // ─── Pembacaan Error Log ─────────────────────
      stream.stderr.on('data', (data) => {
        const errOut = data.toString();
        console.log('[STDERR]', errOut);

        try {
          // fallback interaktif sesuai kode asli
          stream.write("7\n");
          stream.write(`${newuser}\n`);
          stream.write(`${newpw}\n`);
        } catch (e) {
          // abaikan jika stream sudah tertutup
        }
      });
    });
  })

  // ─── Error Koneksi ──────────────────────────────
  .on('error', (err) => {
    console.error('Connection Error:', err);
    bot.sendMessage(
      chatId,
      '❌ 𝗞𝗼𝗻𝗲𝗸𝘀𝗶 𝗴𝗮𝗴𝗮𝗹 — 𝗜𝗣 𝗮𝘁𝗮𝘂 𝗸𝗮𝘁𝗮𝘀𝗮𝗻𝗱𝗶 𝘁𝗶𝗱𝗮𝗸 𝘃𝗮𝗹𝗶𝗱.'
    );
  });

  // ─── Eksekusi Koneksi ───────────────────────────
  try {
    conn.connect(connSettings);
  } catch (error) {
    console.error('Conn.connect exception:', error);
    bot.sendMessage(
      chatId,
      `❌ 𝗚𝗮𝗴𝗮𝗹 𝗺𝗲𝗺𝘂𝗹𝗮𝗶 𝗸𝗼𝗻𝗲𝗸𝘀𝗶.\n\n📌 𝗗𝗲𝘁𝗮𝗶𝗹: ${error.message}`
    );
  }
});

// ─── Command: /installpanel ────────────────────────────────
bot.onText(/^\/installpanel (.+)$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const input = match[1];

  // Ganti dengan daftar user premium kamu
  const isPremium = premiumUsers.includes(String(userId));
  if (!isPremium) {
    return bot.sendMessage(chatId, "⚠️ Fitur ini khusus *User Premium!*", {
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: "💬 HUBUNGI ADMIN", url: "https://t.me/lightsecrett" }]
        ]
      }
    });
  }

  // Validasi format input
  if (!input.includes("|")) {
    return bot.sendMessage(
      chatId,
      "❌ Format salah!\nGunakan:\n`/installpanel ipvps|pwvps|panel.com|node.com|ramserver`",
      { parse_mode: "Markdown" }
    );
  }

  const [ipvps, pwvps, domainpanel, domainnode, ramserver] = input.split("|").map(v => v.trim());
  if (!ipvps || !pwvps || !domainpanel || !domainnode || !ramserver) {
    return bot.sendMessage(
      chatId,
      "❌ Format salah!\nGunakan:\n`/installpanel ipvps|pwvps|panel.com|node.com|ramserver`",
      { parse_mode: "Markdown" }
    );
  }

  const conn = new Client();
  const user = "admin";
  const pass = "admin001";
  const scriptPanel = "bash <(curl -s https://pterodactyl-installer.se)";
  const scriptNode = "bash <(curl -s https://raw.githubusercontent.com/Bangsano/Autoinstaller-Theme-Pterodactyl/main/createnode.sh)";

  try {
    bot.sendMessage(
      chatId,
      `⏳ Menghubungkan ke VPS *${ipvps}*...\nProses instalasi *Panel + Node Wings* dimulai...`,
      { parse_mode: "Markdown" }
    );

    conn
      .on("ready", () => {
        bot.sendMessage(chatId, "⚙️ Koneksi berhasil! Memulai instalasi *Panel...*", { parse_mode: "Markdown" });

        conn.exec(scriptPanel, (err, stream) => {
          if (err) {
            try { conn.end(); } catch (e) {}
            return bot.sendMessage(chatId, `❌ Gagal menjalankan script Panel!\n\`${err.message}\``, { parse_mode: "Markdown" });
          }

          let output = "";

          stream.on("data", (data) => {
            const str = data.toString();
            output += str;

            // Auto Input untuk installer panel
            if (str.includes("Input 0-6")) stream.write("0\n");
            if (str.includes("(y/N)")) stream.write("y\n");
            if (str.includes("Database name")) stream.write(`${user}\n`);
            if (str.includes("Database username")) stream.write(`${user}\n`);
            if (str.includes("Password (press enter")) stream.write(`${pass}\n`);
            if (str.includes("Select timezone")) stream.write("Asia/Jakarta\n");
            if (str.includes("Provide the email")) stream.write("admin@gmail.com\n");
            if (str.includes("Email address for the initial admin account")) stream.write("admin@gmail.com\n");
            if (str.includes("Username for the initial admin account")) stream.write(`${user}\n`);
            if (str.includes("First name")) stream.write("adm\n");
            if (str.includes("Last name")) stream.write("adm\n");
            if (str.includes("Password for the initial admin account")) stream.write(`${pass}\n`);
            if (str.includes("Set the FQDN")) stream.write(`${domainpanel}\n`);
            if (str.includes("automatically configure UFW")) stream.write("y\n");
            if (str.includes("configure HTTPS")) stream.write("y\n");
            if (str.includes("Select the appropriate number")) stream.write("1\n");
            if (str.includes("I agree")) stream.write("y\n");
            if (str.includes("Proceed anyways")) stream.write("y\n");
            if (str.includes("(yes/no)")) stream.write("yes\n");
            if (str.includes("Initial configuration completed")) stream.write("y\n");
            if (str.includes("Still assume SSL")) stream.write("y\n");
            if (str.includes("Please read the Terms")) stream.write("y\n");
            if (str.includes("(A)gree/(C)ancel")) stream.write("A\n");
          });

          stream.stderr.on("data", (data) => {
            output += `\n[ERROR] ${data.toString()}`;
          });

          // Ketika instalasi panel selesai
          stream.on("close", (code, signal) => {
            bot.sendMessage(chatId, "✅ Instalasi Panel selesai! Melanjutkan instalasi Node Wings...", { parse_mode: "Markdown" });

            conn.exec(scriptNode, (err2, stream2) => {
              if (err2) {
                try { conn.end(); } catch (e) {}
                return bot.sendMessage(chatId, `❌ Gagal menjalankan script Node!\n\`${err2.message}\``, { parse_mode: "Markdown" });
              }

              let nodeOutput = "";

              stream2.on("data", (data) => {
                const s = data.toString();
                nodeOutput += s;

                if (s.includes("Masukkan nama lokasi:")) stream2.write("SGP\n");
                if (s.includes("Masukkan deskripsi lokasi:")) stream2.write("VPS PREMIUM BY 𝙡𝙞𝙜𝙝𝙩𝙨𝙚𝙘𝙧𝙚𝙩SHOP 🔱\n");
                if (s.includes("Masukkan domain:")) stream2.write(`${domainnode}\n`);
                if (s.includes("Masukkan nama node:")) stream2.write("NODES\n");
                if (s.includes("Masukkan RAM")) stream2.write(`${ramserver}\n`);
                if (s.includes("Masukkan jumlah maksimum disk")) stream2.write(`${ramserver}\n`);
                if (s.includes("Masukkan Locid:")) stream2.write("1\n");
              });

              stream2.stderr.on("data", (data) => {
                nodeOutput += `\n[ERROR] ${data.toString()}`;
              });

              stream2.on("close", (code2, signal2) => {
                try { conn.end(); } catch (e) {}

                const cleanOut = nodeOutput.trim().slice(-3800) || "(tidak ada output)";
                const teks = `✅ *Instalasi selesai!*\n\n📦 *Akun Panel:*\n👤 Username: \`${user}\`\n🔑 Password: \`${pass}\`\n🌐 Domain: \`${domainpanel}\`\n\n🧩 *Node:* ${domainnode}\n💾 RAM: ${ramserver} MB\n\n📘 Jalankan Wings pakai:\n\`/startwings ${ipvps}|${pwvps}|tokenwings\`\n\n🧾 Output terakhir:\n\`\`\`${cleanOut}\`\`\``;

                bot.sendMessage(chatId, teks, { parse_mode: "Markdown" });
              });
            });
          });
        });
      })
      .on("error", (err) => {
        try { conn.end(); } catch (e) {}
        bot.sendMessage(chatId, `❌ Gagal terhubung ke VPS!\nPeriksa IP dan Password.\n\nError:\n\`${err.message}\``, { parse_mode: "Markdown" });
      });

    conn.connect({
      host: ipvps,
      port: 22,
      username: "root",
      password: pwvps,
      readyTimeout: 20000,
    });
  } catch (e) {
    try { conn.end(); } catch (err) {}
    console.error("Error /installpanel:", e);
    bot.sendMessage(chatId, "❌ Terjadi kesalahan internal. Coba lagi nanti.");
  }
});

// ─── /uninstallpanel ───────────────────────────────
bot.onText(/^\/uninstallpanel (.+)$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const input = match[1];

  // Cek user premium
  const isPremium = premiumUsers.includes(String(userId));
  if (!isPremium) {
    return bot.sendMessage(chatId, "⚠️ Fitur ini khusus *User Premium!*", {
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: "💬 HUBUNGI ADMIN", url: "https://t.me/lightsecrett" }]
        ]
      }
    });
  }

  // Validasi format input
  if (!input.includes("|")) {
    return bot.sendMessage(
      chatId,
      "❌ Format salah!\nGunakan:\n`/uninstallpanel ipvps|pwvps`",
      { parse_mode: "Markdown" }
    );
  }

  const [ipvps, pwvps] = input.split("|").map(v => v.trim());
  if (!ipvps || !pwvps) {
    return bot.sendMessage(
      chatId,
      "❌ Format salah!\nGunakan:\n`/uninstallpanel ipvps|pwvps`",
      { parse_mode: "Markdown" }
    );
  }

  const conn = new Client();
  const scriptUninstall = `bash <(curl -s https://pterodactyl-installer.se)`;

  try {
    bot.sendMessage(
      chatId,
      `⏳ Menghubungkan ke VPS *${ipvps}*...\nMemulai proses *uninstall panel*...`,
      { parse_mode: "Markdown" }
    );

    conn
      .on("ready", () => {
        bot.sendMessage(chatId, "⚙️ Koneksi berhasil! Memulai proses *uninstall panel...*", {
          parse_mode: "Markdown"
        });

        conn.exec(scriptUninstall, (err, stream) => {
          if (err) {
            try { conn.end(); } catch (e) {}
            return bot.sendMessage(chatId, `❌ Gagal menjalankan script!\n\`${err.message}\``, { parse_mode: "Markdown" });
          }

          let output = "";

          stream.on("data", (data) => {
            const str = data.toString();
            output += str;

            // Auto input interaktif untuk uninstall
            if (str.includes("Input 0-6")) stream.write("6\n");
            if (str.includes("(y/N)")) stream.write("y\n");
            if (str.includes("* Choose the panel user (to skip don't input anything):")) stream.write("\n");
            if (str.includes("* Choose the panel database (to skip don't input anything):")) stream.write("\n");
          });

          stream.stderr.on("data", (data) => {
            output += `\n[ERROR] ${data.toString()}`;
          });

          stream.on("close", (code, signal) => {
            try { conn.end(); } catch (e) {}

            const cleanOut = output.trim().slice(-2000) || "(tidak ada output)";
            const teks = `✅ *Uninstall Panel selesai!*\n\n📘 VPS: \`${ipvps}\`\n🧹 Panel berhasil dihapus dari sistem.\n\n🧾 Output terakhir:\n\`\`\`${cleanOut}\`\`\``;
            bot.sendMessage(chatId, teks, { parse_mode: "Markdown" });
          });
        });
      })
      .on("error", (err) => {
        try { conn.end(); } catch (e) {}
        bot.sendMessage(chatId, `❌ Gagal terhubung ke VPS!\nPeriksa IP dan Password.\n\nError:\n\`${err.message}\``, { parse_mode: "Markdown" });
      });

    conn.connect({
      host: ipvps,
      port: 22,
      username: "root",
      password: pwvps,
      readyTimeout: 20000,
    });
  } catch (e) {
    try { conn.end(); } catch (err) {}
    console.error("Error /uninstallpanel:", e);
    bot.sendMessage(chatId, "❌ Terjadi kesalahan internal. Coba lagi nanti.");
  }
});

 // ─── /startwings ────────────────────

bot.onText(/^\/(startwings|swings) (.+)$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const input = match[2];

  // ✅ Cek Owner & Premium
  const isOwner = owner.includes(String(userId));
  const isPremium = premiumUsers.includes(String(userId));

  if (!isOwner && !isPremium) {
    return bot.sendMessage(chatId, "⚠️ Fitur Khusus User Premium!!", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "💬 HUBUNGI ADMIN", url: "https://t.me/lightsecrett" }],
        ],
      },
    });
  }

  // ✅ Validasi format input
  if (!input.includes('|')) {
    return bot.sendMessage(
      chatId,
      '❌ Salah format!\nGunakan seperti ini:\n`/startwings ipvps|pwvps|token_node`',
      { parse_mode: 'Markdown' }
    );
  }

  const [ipvps, pwvps, token] = input.split('|').map((i) => i.trim());
  if (!ipvps || !pwvps || !token) {
    return bot.sendMessage(
      chatId,
      '❌ Salah format!\nGunakan seperti ini:\n`/startwings ipvps|pwvps|token_node`',
      { parse_mode: 'Markdown' }
    );
  }

  const conn = new Client();
  const fullCommand = `${token} && systemctl start wings`;

  try {
    await bot.sendMessage(
      chatId,
      `⏳ Menghubungkan ke VPS *${ipvps}*...\nSedang menjalankan perintah \`systemctl start wings\``,
      { parse_mode: 'Markdown' }
    );

    conn.on('ready', () => {
      bot.sendMessage(chatId, '⚙️ Koneksi berhasil! Wings sedang dijalankan...');

      conn.exec(fullCommand, { pty: true }, (err, stream) => {
        if (err) {
          try { conn.end(); } catch (e) {}
          return bot.sendMessage(
            chatId,
            `❌ Gagal mengeksekusi perintah:\n\`${err.message}\``,
            { parse_mode: 'Markdown' }
          );
        }

        let output = '';
        let stderrOutput = '';

        stream.on('data', (data) => {
          output += data.toString();
          console.log('[STDOUT]', data.toString());
        });

        stream.stderr.on('data', (data) => {
          stderrOutput += data.toString();
          console.log('[STDERR]', data.toString());
          // beberapa sistem butuh konfirmasi otomatis
          try {
            stream.write('y\n');
            stream.write('systemctl start wings\n');
          } catch (e) {}
        });

        stream.on('close', (code, signal) => {
          try { conn.end(); } catch (e) {}

          let replyText = `✅ *Wings berhasil dijalankan!*\n\nKode keluar: ${code}`;
          if (stderrOutput) {
            replyText += `\n\n⚠️ *Catatan STDERR:*\n\`\`\`${stderrOutput.slice(-1000)}\`\`\``;
          }

          bot.sendMessage(chatId, replyText, { parse_mode: 'Markdown' });
        });
      });
    });

    conn.on('error', (err) => {
      try { conn.end(); } catch (e) {}
      bot.sendMessage(
        chatId,
        `❌ Gagal terhubung ke VPS!\nPeriksa IP & Password kamu.\n\nError:\n\`${err.message}\``,
        { parse_mode: 'Markdown' }
      );
    });

    conn.connect({
      host: ipvps,
      port: 22,
      username: 'root',
      password: pwvps,
      readyTimeout: 20000,
    });
  } catch (e) {
    try { conn.end(); } catch (err) {}
    console.error('Error /startwings:', e);
    bot.sendMessage(chatId, '❌ Terjadi kesalahan internal. Coba lagi nanti.');
  }
});

bot.onText(/^\/uninstallwings(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const input = match[1];

  // ✅ Cek Owner & Premium
  const isOwner = owner.includes(String(userId));
  const isPremium = premiumUsers.includes(String(userId));

  if (!isOwner && !isPremium) {
    return bot.sendMessage(chatId, "⚠️ Fitur Khusus User Premium!!", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "💬 HUBUNGI ADMIN", url: "https://t.me/lightsecrett" }],
        ],
      },
    });
  }

  // ✅ Validasi input
  if (!input || !input.includes("|")) {
    return bot.sendMessage(
      chatId,
      "❌ Format salah!\nGunakan seperti ini:\n`/uninstallwings ip|password`",
      { parse_mode: "Markdown" }
    );
  }

  const [ipvps, pwvps] = input.split("|").map((i) => i.trim());
  if (!ipvps || !pwvps) {
    return bot.sendMessage(
      chatId,
      "❌ Format salah!\nGunakan seperti ini:\n`/uninstallwings ip|password`",
      { parse_mode: "Markdown" }
    );
  }

  const conn = new Client();
  const script = `
systemctl stop wings
systemctl disable wings
rm -f /etc/systemd/system/wings.service
rm -f /usr/local/bin/wings
rm -rf /etc/pterodactyl
rm -rf /var/lib/pterodactyl
`;

  try {
    await bot.sendMessage(
      chatId,
      `🛠 Menghubungkan ke VPS *${ipvps}*...\nSedang menghapus Wings dan membersihkan port...`,
      { parse_mode: "Markdown" }
    );

    conn.on("ready", () => {
      bot.sendMessage(chatId, "⚙️ Koneksi berhasil! Wings sedang dihapus...");

      conn.exec(script, { pty: true }, (err, stream) => {
        if (err) {
          conn.end();
          return bot.sendMessage(chatId, `❌ Gagal eksekusi command:\n\`${err.message}\``, { parse_mode: "Markdown" });
        }

        let output = "";
        let stderrOutput = "";

        stream.on("data", (data) => {
          output += data.toString();
          console.log("[STDOUT]", data.toString());
        });

        stream.stderr.on("data", (data) => {
          stderrOutput += data.toString();
          console.log("[STDERR]", data.toString());
        });

        stream.on("close", (code) => {
          conn.end();
          let reply = `✅ *Wings berhasil dihapus dari VPS ${ipvps}*\n🧹 Port 8080 & 2022 juga dibersihkan.\n\nKode keluar: ${code}`;
          if (stderrOutput) {
            reply += `\n\n⚠️ *Catatan STDERR:*\n\`\`\`${stderrOutput.slice(-800)}\`\`\``;
          }
          bot.sendMessage(chatId, reply, { parse_mode: "Markdown" });
        });
      });
    });

    conn.on("error", (err) => {
      bot.sendMessage(chatId, `❌ Tidak bisa konek ke VPS:\n\`${err.message}\``, { parse_mode: "Markdown" });
    });

    conn.connect({
      host: ipvps,
      port: 22,
      username: "root",
      password: pwvps,
      readyTimeout: 20000,
    });
  } catch (e) {
    try { conn.end(); } catch {}
    console.error("Error /uninstallwings:", e);
    bot.sendMessage(chatId, "❌ Terjadi kesalahan internal. Coba lagi nanti.");
  }
});

 // ─── /installwings dan uninstall wings ────────────────────
bot.onText(/^\/installwings (.+)$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const input = match[1];

  // ✅ Cek Owner & Premium
  const isOwner = owner.includes(String(userId));
  const isPremium = premiumUsers.includes(String(userId));

  if (!isOwner && !isPremium) {
    return bot.sendMessage(chatId, "⚠️ Fitur Khusus User Premium!!", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "💬 HUBUNGI ADMIN", url: "https://t.me/lightsecrett" }],
        ],
      },
    });
  }

  // ✅ Validasi format input
  if (!input.includes("|")) {
    return bot.sendMessage(
      chatId,
      "⚠️ Format salah!\nGunakan:\n`/installwings IpVps|PwVps|domainpanel|domainnode`",
      { parse_mode: "Markdown" }
    );
  }

  const parts = input.split("|").map((i) => i.trim());
  if (parts.length !== 4) {
    return bot.sendMessage(
      chatId,
      "⚠️ Format salah!\nGunakan:\n`/installwings IpVps|PwVps|domainpanel|domainnode`",
      { parse_mode: "Markdown" }
    );
  }

  const [ipvps, passwd, domainpanel, domainnode] = parts;

  const conn = new Client();
  const command = `bash <(curl -s https://pterodactyl-installer.se)`;
  const emailrandom = `syahv2d@gmail.com`;
  const userDb = `syahv2d${Math.random().toString(36).substring(7)}`;
  const passwordDb = `syahv2d${Math.random().toString(36).substring(7)}`;

  try {
    await bot.sendMessage(
      chatId,
      `⏳ Menghubungkan ke VPS *${ipvps}*...\nSedang menginstall Wings...`,
      { parse_mode: "Markdown" }
    );

    conn
      .on("ready", () => {
        bot.sendMessage(
          chatId,
          `✅ Koneksi berhasil!\nMemulai instalasi wings...\n🌐 Panel: ${domainpanel}\n🛰️ Node: ${domainnode}\n📧 Email: ${emailrandom}`
        );

        conn.exec(command, { pty: true }, (err, stream) => {
          if (err) {
            conn.end();
            return bot.sendMessage(chatId, `❌ Gagal eksekusi command: ${err.message}`);
          }

          stream
            .on("data", (data) => {
              const output = data.toString();
              console.log("[STDOUT]", output);

              if (output.includes("Input 0-6")) stream.write("1\n");
              if (output.includes("(y/N)")) stream.write("y\n");
              if (output.includes("Enter the panel address")) stream.write(`${domainpanel}\n`);
              if (output.includes("Database host username")) stream.write(`${userDb}\n`);
              if (output.includes("Database host password")) stream.write(`${passwordDb}\n`);
              if (output.includes("Set the FQDN to use for Let's Encrypt")) stream.write(`${domainnode}\n`);
              if (output.includes("Enter email address")) stream.write(`${emailrandom}\n`);
            })
            .stderr.on("data", (data) => {
              console.log("[STDERR]", data.toString());
            })
            .on("close", (code) => {
              conn.end();
              bot.sendMessage(
                chatId,
                `✅ Instalasi Wings selesai (exit code: ${code})\n🌐 Panel: ${domainpanel}\n🛰️ Node: ${domainnode}`
              );
            });
        });
      })
      .on("error", (err) => {
        bot.sendMessage(chatId, `❌ Gagal terhubung ke VPS: ${err.message}`);
      })
      .connect({
        host: ipvps,
        port: 22,
        username: "root",
        password: passwd,
        readyTimeout: 20000,
      });
  } catch (e) {
    try { conn.end(); } catch {}
    console.error("Error /installwings:", e);
    bot.sendMessage(chatId, "❌ Terjadi kesalahan internal, coba lagi nanti.");
  }
});

 // ─── /createadmin ────────────────────
bot.onText(/\/createadmin (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const adminUsers = owner;
  const isAdmin = adminUsers.includes(String(msg.from.id));
  if (!isAdmin) {
    bot.sendMessage(
      chatId,
      "Fitur Khusus Owner!!",
      {
        reply_markup: {
          inline_keyboard: [
            [{ text: "HUBUNGI ADMIN", url: "https://t.me/lightsecrett" }],
          ],
        },
      }
    );
    return;
  }
  const commandParams = match[1].split(",");
  const panelName = commandParams[0].trim();
  const telegramId = commandParams[1].trim();
  if (commandParams.length < 2) {
    bot.sendMessage(
      chatId,
      "Format Salah! Penggunaan: /createadmin namapanel,idtele"
    );
    return;
  }
  const password = panelName + "403";
  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        email: `${panelName}@LIGHT.SECRET`,
        username: panelName,
        first_name: panelName,
        last_name: "Memb",
        language: "en",
        root_admin: true,
        password: password,
      }),
    });
    const data = await response.json();
    if (data.errors) {
      bot.sendMessage(chatId, JSON.stringify(data.errors[0], null, 2));
      return;
    }
    const user = data.attributes;
    const userInfo = `
TYPE: user
➟ ID: ${user.id}
➟ USERNAME: ${user.username}
➟ EMAIL: ${user.email}
➟ NAME: ${user.first_name} ${user.last_name}
➟ LANGUAGE: ${user.language}
➟ ADMIN: ${user.root_admin}
➟ CREATED AT: ${user.created_at}
    `;
    bot.sendMessage(chatId, userInfo);
    bot.sendMessage(
      telegramId,
      `
DETAIL ADMIN PANEL ANDA :
👑 Login : ${domain}
💣 Username : ${user.username}
🔑 Password : ${password} 

📍 ᴄᴀᴛᴀᴛᴀɴ ᴘᴇɴᴛɪɴɢ:
    ᴡᴇʙ ᴊᴀɴɢᴀɴ ᴅɪ ʙᴜᴀᴛ ᴅᴅᴏs
    ᴛᴜᴛᴜᴘɪ ᴅᴏᴍᴀɪɴ ᴋᴇᴛɪᴋᴀ ᴅɪ ss
    ᴅᴏᴍᴀɪɴ ᴊᴀɴɢᴀɴ ᴅɪ sᴇʙᴀʀ
    ᴍᴏʜᴏɴ ᴘᴇʀʜᴀᴛɪᴀɴ
    EXPIRED SAMPAI                     DDOS
    ALL TRANSAKSI NO REFFUND 🙏
    JANGAN LUPA SS DONE
    PERATURAN (WAJIB DI BACA) :
    1. GA BOLEH BUAT AKUN PANEL PAKE SC C PANEL HARUS BUAT MANUAL
    2. GA BOLEH BUAT AKUN ADMIN PANEL PAKE SC C ADMIN HARUS BUAT MANUAL
    3. NAMA BELAKANG EMAIL HARUS  @LIGHT.SECRET JANGAN @gmail.com ATAU YANG LAINNYA
    4. JANGAN RUSUH
    5. IKUTI ATURAN
    `
    );
  } catch (error) {
    console.error(error);
    bot.sendMessage(
      chatId,
      "Terjadi kesalahan dalam pembuatan admin. Silakan coba lagi nanti."
    );
  }
});

// ======== FITUR SUBDOMAIN (KHUSUS OWNER & PREMIUM) ========
const subdomainFile = "subdomain.json";

function loadSubdomainData() {
  try {
    return JSON.parse(fs.readFileSync(subdomainFile, "utf8"));
  } catch (e) {
    console.error("❌ Gagal membaca subdomain.json:", e.message);
    return {};
  }
}

// === Perintah: /subdo atau /subdomain host|ip ===
bot.onText(/\/(subdo|subdomain) (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = String(msg.from.id);
  const text = match[2]; // match[1] = subdo/subdomain, match[2] = argumen host|ip
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));

  if (userId !== owner && !premiumUsers.includes(userId)) {
    return bot.sendMessage(chatId, "❌ Hanya Owner dan User Premium yang bisa menggunakan fitur ini!");
  }

  if (!text.includes("|")) {
    return bot.sendMessage(chatId, "Format salah!\nContoh: `/subdo host|ipserver`", { parse_mode: "Markdown" });
  }

  const [host, ip] = text.split("|").map(i => i.trim());
  const subdomains = loadSubdomainData();
  const dom = Object.keys(subdomains);

  if (dom.length === 0) return bot.sendMessage(chatId, "❌ Tidak ada domain tersedia!");

  // Buat keyboard domain
  const keyboard = {
    inline_keyboard: dom.map((d, i) => [
      { text: `🌐 ${host}.${d}`, callback_data: `create_domain_${i}_${host}|${ip}` }
    ])
  };

  bot.sendMessage(chatId, "🔹 Pilih domain yang tersedia:", { reply_markup: keyboard });
});

// === Callback: Membuat Subdomain ===
bot.on("callback_query", async (query) => {
  const chatId = query.message.chat.id;
  const data = query.data;
  const userId = String(query.from.id);
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));

  if (!data.startsWith("create_domain_")) return;

  if (userId !== owner && !premiumUsers.includes(userId)) {
    await bot.answerCallbackQuery(query.id, { text: "❌ Tidak diizinkan!" });
    return;
  }

  await bot.answerCallbackQuery(query.id, { text: "⏳ Membuat subdomain..." });

  const [_, index, arg] = data.match(/^create_domain_(\d+)_(.+)$/);
  const [host, ip] = arg.split("|").map(i => i.trim());
  const subdomains = loadSubdomainData();
  const dom = Object.keys(subdomains);
  const domainIndex = Number(index);

  if (domainIndex < 0 || domainIndex >= dom.length)
    return bot.sendMessage(chatId, "❌ Domain tidak ditemukan!");

  const tldnya = dom[domainIndex];
  const { apitoken, zone } = subdomains[tldnya];

  // Fungsi membuat subdomain via Cloudflare API
  async function createSubDomain(host, ip) {
    try {
      const response = await axios.post(
        `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
        {
          type: "A",
          name: `${host}.${tldnya}`,
          content: ip,
          ttl: 3600,
          proxied: false
        },
        {
          headers: {
            Authorization: `Bearer ${apitoken}`,
            "Content-Type": "application/json"
          }
        }
      );

      const res = response.data;
      if (res.success) {
        return {
          success: true,
          name: res.result.name,
          ip: res.result.content
        };
      } else {
        return { success: false, error: "Gagal membuat subdomain" };
      }
    } catch (e) {
      const errorMsg = e.response?.data?.errors?.[0]?.message || e.message || "Terjadi kesalahan";
      return { success: false, error: errorMsg };
    }
  }

  const result = await createSubDomain(host.toLowerCase(), ip);
  if (result.success) {
    bot.sendMessage(
      chatId,
      `✅ *Berhasil membuat subdomain*\n\n🌐 *Subdomain:* ${result.name}\n📌 *IP Server:* ${result.ip}`,
      { parse_mode: "Markdown" }
    );
  } else {
    bot.sendMessage(chatId, `❌ Gagal membuat subdomain:\n${result.error}`);
  }
});

// Handle callback query dari tombol
bot.on('callback_query', (callbackQuery) => {
    const chatId = callbackQuery.message.chat.id;
    const messageId = callbackQuery.message.message_id;
    const username = callbackQuery.from.username || callbackQuery.from.first_name;

    if (callbackQuery.data === 'panel_menu') {
        sendPanelMenu(chatId, messageId, username);
    } else if (callbackQuery.data === 'owner_menu') {
        sendOwnerMenu(chatId, messageId, username);
    } else if (callbackQuery.data === 'fitur_menu') {
        sendFiturMenu(chatId, messageId, username);
    } else if (callbackQuery.data === 'start_menu') {
        sendStartMenu(chatId, messageId, username);
    }

    bot.answerCallbackQuery(callbackQuery.id);
});

console.log(chalk.green.bold(`

█░ █ █▀▀ █░█ ▀█▀  
█▄ █ █▄█ █▀█ ░█░  
█▀ █▀▀ █▀ █▀█ █▀▀ ▀█▀  
▄█ ██▄ █▄ █▀▄ ██▄ ░█░`));
console.log(chalk.yellow.bold('bot lightsecret berhasil tersambung!!'));
console.log(' ');
console.log(' ');
console.log(chalk.blue.bold('Contact Dev:'));
console.log(chalk.yellow.bold('WhatsApp: +62××××××'));
console.log(chalk.yellow.bold('Telegram: @lightsecrett'));
console.log(chalk.green.bold('hargai hasil karya lightsecret'));
console.log(chalk.green.bold('developer.'));